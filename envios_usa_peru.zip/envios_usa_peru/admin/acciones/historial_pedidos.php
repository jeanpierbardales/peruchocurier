<?php
session_start();
include '../../config/conexion.php';

header('Content-Type: application/json');

if (!isset($_POST['usuario_id'])) {
    echo json_encode(["status" => "error", "message" => "ID de usuario no proporcionado"]);
    exit();
}

$usuario_id = intval($_POST['usuario_id']);

$sql = "SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY fecha_registro DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $html = "<h4>Historial de Pedidos</h4>";
    $html .= "<table class='table table-bordered'><thead><tr><th>ID</th><th>Productos</th><th>Precio</th><th>Seguimiento</th><th>Estado</th></tr></thead><tbody>";

    while ($pedido = $result->fetch_assoc()) {
        $html .= "<tr>
                    <td>{$pedido['id']}</td>
                    <td>{$pedido['productos']}</td>
                    <td>\${$pedido['precio']}</td>
                    <td>{$pedido['seguimiento']}</td>
                    <td>{$pedido['estado']}</td>
                  </tr>";
    }

    $html .= "</tbody></table>";

    echo json_encode(["status" => "success", "html" => $html]);
} else {
    echo json_encode(["status" => "error", "message" => "No hay pedidos anteriores."]);
}

$stmt->close();
$conn->close();
