<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die("❌ Acceso denegado.");
}

include '../../config/conexion.php';

// Validar usuario_id
$usuario_id = isset($_GET['usuario_id']) ? intval($_GET['usuario_id']) : 0;
if ($usuario_id <= 0) {
    die("⚠️ ID de usuario no proporcionado o inválido.");
}

// Consulta para obtener pedidos del usuario
$sql = "SELECT id, productos, precio, seguimiento, estado, fecha_registro 
        FROM pedidos 
        WHERE usuario_id = ? 
        ORDER BY fecha_registro DESC";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<pre>"; // Esto hará que se muestre en formato legible
    var_dump($result->fetch_all(MYSQLI_ASSOC)); // 🔎 Muestra los datos obtenidos
    echo "</pre>";
    
    if ($result->num_rows > 0) {
        echo "<h4 class='mt-3'>📜 Historial de Pedidos</h4>";
        echo "<table class='table table-striped table-bordered'>";
        echo "<thead class='table-dark'><tr>
                <th>ID</th>
                <th>Productos</th>
                <th>Precio</th>
                <th>Seguimiento</th>
                <th>Estado</th>
                <th>Fecha</th>
              </tr></thead><tbody>";

        while ($pedido = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$pedido['id']}</td>
                    <td>" . htmlspecialchars($pedido['productos']) . "</td>
                    <td>\${$pedido['precio']}</td>
                    <td>" . htmlspecialchars($pedido['seguimiento']) . "</td>
                    <td>" . strtoupper(htmlspecialchars($pedido['estado'])) . "</td>
                    <td>{$pedido['fecha_registro']}</td>
                  </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<div class='alert alert-warning' role='alert'>⚠️ No hay pedidos anteriores.</div>";
    }

    $stmt->close();
} else {
    echo "<div class='alert alert-danger' role='alert'>❌ Error en la consulta SQL: " . $conn->error . "</div>";
}

$conn->close();
?>
