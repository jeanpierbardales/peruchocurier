<?php
include '../../config/conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $pedido_id = $_POST['id'] ?? null;
    $estado = $_POST['estado'] ?? null;

    if (!$pedido_id || !$estado) {
        echo json_encode(["status" => "error", "message" => "Datos inválidos"]);
        exit();
    }

    $sql = "UPDATE pedidos SET estado = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $estado, $pedido_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Estado actualizado"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al actualizar"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Método no permitido"]);
}
