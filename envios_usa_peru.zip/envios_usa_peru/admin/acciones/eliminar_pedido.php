<?php
include '../../config/conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $pedido_id = $_POST['id'] ?? null;

    if (!$pedido_id) {
        echo json_encode(["status" => "error", "message" => "ID inválido"]);
        exit();
    }

    // En lugar de eliminar, marcamos el pedido como "cancelado"
    $sql = "UPDATE pedidos SET estado = 'cancelado' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $pedido_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Pedido marcado como cancelado"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al cancelar el pedido"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Método no permitido"]);
}
