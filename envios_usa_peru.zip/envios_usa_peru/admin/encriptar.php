<?php
include '../config/conexion.php';

// Definir usuario y contraseña
$usuario = "JeanLujanCarrion"; // Cambia esto por tu usuario deseado
$password = "71467917"; // Cambia esto por la contraseña deseada

// Encriptar la contraseña
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insertar en la base de datos
$sql = "INSERT INTO admin (usuario, password) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $usuario, $hashed_password);

if ($stmt->execute()) {
    echo "✅ Usuario administrador creado correctamente.";
} else {
    echo "❌ Error al crear el usuario: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
