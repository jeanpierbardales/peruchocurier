<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include '../config/conexion.php';

$sql = "SELECT id, nombre, apellidos, email FROM usuarios ORDER BY nombre ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Usuarios</h2>
        <a href="../admin/index.php" class="btn btn-secondary">Volver</a>
        <table class="table table-striped mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($usuario = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $usuario['id'] ?></td>
                    <td><?= htmlspecialchars($usuario['nombre'] . " " . $usuario['apellidos']) ?></td>
                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                    <td>
                        <button class="btn btn-primary ver-historial" data-usuario="<?= $usuario['id'] ?>">Ver Historial</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div id="historialPedidos" class="mt-4"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $(".ver-historial").on("click", function() {
            let usuarioId = $(this).data("usuario");

            console.log("📌 Cargando historial del usuario ID:", usuarioId);

            $("#historialPedidos").html("<p>Cargando historial...</p>");

            $.ajax({
                url: "../admin/acciones/historial_pedidos.php",
                type: "POST",
                data: { usuario_id: usuarioId },
                dataType: "json",
                success: function(res) {
                    console.log("📌 Respuesta del servidor:", res);

                    if (res.status === "success") {
                        $("#historialPedidos").html(res.html);
                    } else {
                        $("#historialPedidos").html("<p>No se encontraron pedidos previos.</p>");
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error("❌ Error AJAX:", textStatus, errorThrown);
                    $("#historialPedidos").html("<p>Error al cargar el historial.</p>");
                }
            });
        });
    });
</script>

</body>
</html>
