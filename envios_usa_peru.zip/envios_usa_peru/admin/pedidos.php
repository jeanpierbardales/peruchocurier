<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include '../config/conexion.php';

// Obtener pedidos con nombre y apellido del usuario
$sql = "SELECT p.*, u.nombre, u.apellidos FROM pedidos p 
        JOIN usuarios u ON p.usuario_id = u.id 
        ORDER BY p.fecha_registro DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Pedidos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container mt-4">
        <h2>Administración de Pedidos</h2>
        <a href="../admin/index.php" class="btn btn-secondary mb-3">Volver</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Productos</th>
                    <th>Precio</th>
                    <th>Seguimiento</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($pedido = $result->fetch_assoc()): ?>
                <tr id="pedido-<?= $pedido['id'] ?>">
                    <td><?= $pedido['id'] ?></td>
                    <td><?= htmlspecialchars($pedido['nombre'] . " " . $pedido['apellidos']) ?></td>
                    <td><?= htmlspecialchars($pedido['productos']) ?></td>
                    <td>$<?= number_format($pedido['precio'], 2) ?></td>
                    <td><?= htmlspecialchars($pedido['seguimiento']) ?></td>
                    <td>
                        <select class="form-select estado-select" data-id="<?= $pedido['id'] ?>">
                            <option value="pendiente" <?= $pedido['estado'] == 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                            <option value="procesando" <?= $pedido['estado'] == 'procesando' ? 'selected' : '' ?>>Procesando</option>
                            <option value="enviado" <?= $pedido['estado'] == 'enviado' ? 'selected' : '' ?>>Enviado</option>
                            <option value="entregado" <?= $pedido['estado'] == 'entregado' ? 'selected' : '' ?>>Entregado</option>
                            <option value="finalizado" <?= $pedido['estado'] == 'finalizado' ? 'selected' : '' ?>>Finalizado</option>
                        </select>
                    </td>
                    <td>
                        <button class="btn btn-danger eliminar-btn" data-id="<?= $pedido['id'] ?>">Eliminar</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            // Actualizar estado del pedido
            $(".estado-select").change(function() {
                let pedidoId = $(this).data("id");
                let nuevoEstado = $(this).val();
                
                $.post("../admin/acciones/actualizar_estado.php", { id: pedidoId, estado: nuevoEstado }, function(res) {
                    alert(res.message);
                }, "json");
            });

            // Eliminar pedido
            $(".eliminar-btn").click(function() {
                let pedidoId = $(this).data("id");
                if (confirm("¿Estás seguro de eliminar este pedido?")) {
                    $.post("../admin/acciones/eliminar_pedido.php", { id: pedidoId }, function(res) {
                        if (res.status === "success") {
                            $("#pedido-" + pedidoId).remove();
                        } else {
                            alert(res.message);
                        }
                    }, "json");
                }
            });
        });
    </script>
</body>
</html>
