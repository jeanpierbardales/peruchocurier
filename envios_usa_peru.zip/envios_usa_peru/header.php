<?php
$titulo = "Envíos USA - Perú";
$correo = "perucho.courier@gmail.com";
$telefono = "967-929-967";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?></title>
    <link rel="stylesheet" href="../estilos/estilos.css">
</head>
<body>
    <!-- Encabezado -->
    <header>
        <div class="top-bar">
            <span>📧 <?php echo $correo; ?> | 📞 <?php echo $telefono; ?></span>
            <div class="social-icons">
                    <a href="https://www.facebook.com/" target="_blank">Facebook</a> |  
                    <a href="https://www.instagram.com/" target="_blank">Instagram</a> |  
                    <a href="https://www.tiktok.com/" target="_blank">TikTok</a>
<style>
    .top-bar {
    width: 98%; /* Ocupa todo el ancho de la pantalla */
    height: 45px; /* Ajusta la altura según necesites */
    background:rgb(53, 39, 184); /* Fondo amarillo */
    display: flex;
    align-items: center; /* Centrar verticalmente */
    justify-content: space-between; /* Distribuye el contenido */
    padding: 0 20px; /* Espaciado a los lados */
    position: fixed; /* Fija el banner arriba */
    top: 0; /* Asegura que esté en la parte superior */
    left: 0;
    z-index: 1000; /* Asegura que esté por encima del resto */
}

.social-icons a{
    color: white;
}
.menu ul li a {
    text-decoration: none;
    color: rgb(255, 254, 254);
    font-size: 25px;
    font-weight: bold;
    padding: 8px 16px;
    background-color: #ce0a0a; /* Naranja */
    border-radius: 8px;
    transition: 0.3s;
}

</style>
    </div>
    <div class="business-hours">
        ⏳ <strong>Lunes - Viernes:</strong> 9:00 AM - 6:00 PM ⏳
        <strong>Sábado:</strong> 9:00 AM - 12:00 PM
    </div>
        </div>
        <nav class="menu">
            <img src="../img/logo.png" alt="Logo" class="logo">
            <ul>
    <li><a href="index.php">Inicio</a></li>
    <li><a href="nosotros.php">Nosotros</a></li>
    <li><a href="calculadora.php">Calcula tu Pedido</a></li> 
    <li><a href="seguimiento.php">Rastrea tu pedido</a></li>
    <li><a href="apoyo.php">Apoyo</a></li>


    <?php if (!empty($_SESSION['usuario_id'])): ?>
        <li class="menu-dropdown">
            <ul class="submenu">
                <li><a href="dashboard.php">Mi Cuenta</a></li>
                <li><a href="logout.php">Salir</a></li>
            </ul>
        </li>
    <?php else: ?>
        <li><a href="registro.php">Registro</a></li>
        <li><a href="login.php">Iniciar sesión</a></li>
    <?php endif; ?>
</ul>

        </nav>
    </header>
</body>
</html>
