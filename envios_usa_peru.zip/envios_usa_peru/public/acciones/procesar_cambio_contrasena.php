<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

// Guarda datos en un archivo para depuración
file_put_contents("debug_post.txt", print_r($_POST, true));

// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

// Verificar conexión
if ($conexion->connect_error) {
    die(json_encode(["status" => "error", "message" => "Error de conexión: " . $conexion->connect_error]));
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "error", "message" => "Debes iniciar sesión."]);
    exit();
}

// Verificar que se enviaron los datos
if (empty($_POST['contrasena_actual']) || empty($_POST['nueva_contrasena']) || empty($_POST['confirmar_contrasena'])) {
    echo json_encode(["status" => "error", "message" => "Faltan datos en el formulario."]);
    exit();
}

// Obtener datos del formulario
$usuario_id = $_SESSION['usuario_id'];
$contrasena_actual = $_POST['contrasena_actual'];
$nueva_contrasena = $_POST['nueva_contrasena'];
$confirmar_contrasena = $_POST['confirmar_contrasena'];

// Verificar que las contraseñas coincidan
if ($nueva_contrasena !== $confirmar_contrasena) {
    echo json_encode(["status" => "error", "message" => "Las contraseñas no coinciden."]);
    exit();
}

// Obtener la contraseña actual del usuario
$sql = "SELECT password FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);

if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Error en la consulta: " . $conexion->error]);
    exit();
}

$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

if (!$usuario) {
    echo json_encode(["status" => "error", "message" => "Usuario no encontrado."]);
    exit();
}

// Verificar la contraseña actual
if (!password_verify($contrasena_actual, $usuario['password'])) {
    echo json_encode(["status" => "error", "message" => "La contraseña actual es incorrecta."]);
    exit();
}

// Encriptar la nueva contraseña
$nueva_contrasena_hash = password_hash($nueva_contrasena, PASSWORD_DEFAULT);

// Actualizar la contraseña en la base de datos
$sql = "UPDATE usuarios SET password = ? WHERE id = ?";
$stmt = $conexion->prepare($sql);

if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Error en la consulta de actualización: " . $conexion->error]);
    exit();
}

$stmt->bind_param("si", $nueva_contrasena_hash, $usuario_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Contraseña actualizada correctamente."]);
} else {
    echo json_encode(["status" => "error", "message" => "Error al actualizar la contraseña: " . $stmt->error]);
}

$stmt->close();
$conexion->close();
?>
