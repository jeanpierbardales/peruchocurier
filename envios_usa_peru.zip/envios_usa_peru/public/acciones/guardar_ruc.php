<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Método no permitido."]);
    exit();
}

header('Content-Type: application/json');
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "error", "message" => "Debes iniciar sesión."]);
    exit();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

// Verificar conexión
if ($conexion->connect_error) {
    echo json_encode(["status" => "error", "message" => "Error de conexión: " . $conexion->connect_error]);
    exit();
}

// Obtener el ID del usuario autenticado
$usuario_id = $_SESSION['usuario_id'];

// Recibir datos del formulario
$ruc_numero = trim($_POST['ruc_numero'] ?? '');
$ruc_razon_social = trim($_POST['ruc_razon_social'] ?? '');
$ruc_direccion = trim($_POST['ruc_direccion'] ?? '');
$ruc_provincia = trim($_POST['ruc_provincia'] ?? '');
$ruc_pdf = null;

// Manejo del archivo PDF
if (!empty($_FILES['ruc_pdf']['name'])) {
    $directorio_subida = "../uploads/";
    
    // Crear la carpeta si no existe
    if (!is_dir($directorio_subida)) {
        mkdir($directorio_subida, 0777, true);
    }

    $ruta_archivo = $directorio_subida . uniqid() . "_" . basename($_FILES['ruc_pdf']['name']);
    
    if (move_uploaded_file($_FILES['ruc_pdf']['tmp_name'], $ruta_archivo)) {
        $ruc_pdf = $ruta_archivo;
    } else {
        echo json_encode(["status" => "error", "message" => "Error al subir el archivo PDF."]);
        exit();
    }
}

// Insertar o actualizar datos en la tabla usuarios
$sql = "UPDATE usuarios SET 
            ruc_numero = ?, 
            ruc_razon_social = ?, 
            ruc_direccion = ?, 
            ruc_provincia = ?, 
            ruc_pdf = COALESCE(?, ruc_pdf)
        WHERE id = ?";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("sssssi", $ruc_numero, $ruc_razon_social, $ruc_direccion, $ruc_provincia, $ruc_pdf, $usuario_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "RUC actualizado correctamente."]);
} else {
    echo json_encode(["status" => "error", "message" => "Error al actualizar el RUC."]);
}

$stmt->close();
$conexion->close();
?>
