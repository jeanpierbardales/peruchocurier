<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Método no permitido."]);
    exit();
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "error", "message" => "Debes iniciar sesión."]);
    exit();
}

include '../config/conexion.php';

$usuario_id = $_SESSION['usuario_id'];

// Verificar si se ha subido un archivo
if (!isset($_FILES['foto_perfil']) || $_FILES['foto_perfil']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(["status" => "error", "message" => "Error al subir la imagen."]);
    exit();
}

$archivo = $_FILES['foto_perfil'];
$extensiones_permitidas = ['jpg', 'jpeg', 'png'];
$ext = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));

if (!in_array($ext, $extensiones_permitidas)) {
    echo json_encode(["status" => "error", "message" => "Formato no permitido. Usa JPG o PNG."]);
    exit();
}

// Crear carpeta si no existe
$upload_dir = "../uploads/perfiles/";
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Crear un nombre único para la imagen
$nombre_archivo = "perfil_" . $usuario_id . "." . $ext;
$ruta_archivo = $upload_dir . $nombre_archivo;

// Mover el archivo al servidor
if (!move_uploaded_file($archivo['tmp_name'], $ruta_archivo)) {
    echo json_encode(["status" => "error", "message" => "Error al guardar la imagen."]);
    exit();
}

// Guardar la ruta en la base de datos
$ruta_bd = "../uploads/perfiles/" . $nombre_archivo;
$sql = "UPDATE usuarios SET foto_perfil = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $ruta_bd, $usuario_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Foto de perfil actualizada correctamente."]);
} else {
    echo json_encode(["status" => "error", "message" => "Error al actualizar en la base de datos."]);
}

$stmt->close();
$conn->close();
