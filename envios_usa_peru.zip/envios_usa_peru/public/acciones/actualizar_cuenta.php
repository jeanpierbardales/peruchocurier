<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "error", "message" => "No autorizado"]);
    exit();
}

$conexion = new mysqli("localhost", "root", "", "perucho_currier");

if ($conexion->connect_error) {
    echo json_encode(["status" => "error", "message" => "Error de conexión"]);
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$nombre = trim($_POST['nombre']);
$apellidos = trim($_POST['apellidos']);

if (!empty($nombre) && !empty($apellidos)) {
    $sql = "UPDATE usuarios SET nombre = ?, apellidos = ? WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ssi", $nombre, $apellidos, $usuario_id);

    if ($stmt->execute()) {
        $_SESSION['usuario_nombre'] = $nombre;
        $_SESSION['usuario_apellidos'] = $apellidos;
        echo json_encode(["status" => "success", "message" => "Cuenta actualizada correctamente"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al actualizar"]);
    }
    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios"]);
}

$conexion->close();
