<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Método no permitido."]);
    exit;
}

// Guardar datos en debug para ver si llegan
file_put_contents("debug.txt", print_r($_POST, true));

if (empty($_POST)) {
    echo json_encode(["status" => "error", "message" => "No se recibieron datos."]);
    exit;
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

if ($conexion->connect_error) {
    echo json_encode(["status" => "error", "message" => "Error de conexión: " . $conexion->connect_error]);
    exit;
}

// Obtener datos del formulario
$usuario_id = $_SESSION['usuario_id'];
$nombre = trim($_POST['nombre'] ?? '');
$apellidos = trim($_POST['apellidos'] ?? '');
$direccion = trim($_POST['direccion'] ?? '');
$ciudad = trim($_POST['ciudad'] ?? '');
$provincia = trim($_POST['provincia'] ?? '');
$codigo_postal = trim($_POST['codigo_postal'] ?? '');
$telefono = trim($_POST['telefono'] ?? '');

// Validar datos
if (empty($nombre) || empty($apellidos) || empty($direccion) || empty($ciudad) || empty($provincia) || empty($codigo_postal) || empty($telefono)) {
    echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios."]);
    exit;
}

// Verificar si el usuario ya tiene una dirección registrada
$sql_check = "SELECT id FROM direcciones WHERE usuario_id = ?";
$stmt_check = $conexion->prepare($sql_check);
$stmt_check->bind_param("i", $usuario_id);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    // Si ya tiene dirección, hacer UPDATE
    $sql = "UPDATE direcciones SET 
                nombre = ?, 
                apellidos = ?, 
                direccion = ?, 
                ciudad = ?, 
                provincia = ?, 
                codigo_postal = ?, 
                telefono = ? 
            WHERE usuario_id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("sssssssi", $nombre, $apellidos, $direccion, $ciudad, $provincia, $codigo_postal, $telefono, $usuario_id);
} else {
    // Si no tiene dirección, hacer INSERT
    $sql = "INSERT INTO direcciones (usuario_id, nombre, apellidos, direccion, ciudad, provincia, codigo_postal, telefono)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("isssssss", $usuario_id, $nombre, $apellidos, $direccion, $ciudad, $provincia, $codigo_postal, $telefono);
}

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Dirección guardada correctamente."]);
} else {
    echo json_encode(["status" => "error", "message" => "Error al guardar la dirección."]);
}

$stmt->close();
$conexion->close();

