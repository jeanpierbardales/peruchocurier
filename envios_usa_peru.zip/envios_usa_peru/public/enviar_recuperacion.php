<?php
include '../config/conexion.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);

    // Verificar si el correo existe
    $sql = "SELECT id FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $usuario = $result->fetch_assoc();
        $usuario_id = $usuario['id'];
        $token = bin2hex(random_bytes(32)); // Generar un token seguro
        date_default_timezone_set("America/Lima"); // Ajustar la zona horaria si es necesario
        $expira = date("Y-m-d H:i:s", strtotime("+1 hour")); // Expira en 1 hora

        // Guardar el token en la base de datos
        $sql = "INSERT INTO recuperacion (usuario_id, token, expira) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $usuario_id, $token, $expira);

        if ($stmt->execute()) {
            echo "✅ Token insertado correctamente.";

            // Enviar correo con el enlace de recuperación
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Servidor SMTP
                $mail->SMTPAuth = true;
                $mail->Username = 'peruchocourier8@gmail.com'; // Tu correo
                $mail->Password = 'bdgyqohvzgpzbiiy'; // Contraseña de aplicación de Gmail
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('peruchocourier8@gmail.com', 'Soporte');
                $mail->addAddress($email);
                $mail->Subject = 'Recuperación de contraseña';
                $mail->isHTML(true);

                $base_url = "http://localhost/envios_usa_peru/public"; // Asegurar ruta correcta

                $mail->Body = "Haz clic en el siguiente enlace para restablecer tu contraseña: <br><br>
                               <a href='$base_url/restablecer.php?token=$token'>Recuperar contraseña</a>";

                $mail->send();
                echo "📧 Correo enviado con éxito.";
            } catch (Exception $e) {
                echo "❌ Error al enviar el correo: {$mail->ErrorInfo}";
            }
        } else {
            echo "❌ Error al insertar el token: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "❌ Correo no encontrado.";
    }
}
?>
