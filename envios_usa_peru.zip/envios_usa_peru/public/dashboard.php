<?php
// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

include '../config/conexion.php';
include '../header.php';

// Obtener información del usuario
$usuario_id = $_SESSION['usuario_id'];
$sql = "SELECT nombre, apellidos, foto_perfil FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre, $apellidos, $foto_perfil);
$stmt->fetch();
$stmt->close();
$conn->close();

// Si no tiene foto de perfil, usar una por defecto
$foto_perfil = $foto_perfil ?: "../img/user.png";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Perucho Courier</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:rgb(134, 237, 245);
            background: url('../img/vuelo.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            margin-top: 20px;   
        }
        .sidebar {
            background:  rgba(182, 238, 241, 0.59);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            height: 100%;
        }
        .content {
            background: rgba(231, 171, 243, 0.62);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            min-height: 400px;
        }
        .sidebar a {
            text-decoration: none;
            color: #333;
            display: block;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 5px;
            cursor: pointer;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: #1f1f91;
            color: white !important;
        }
        .profile-pic {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
        }
        /* Estilos para los títulos de las secciones */
#content h2, #content h3, #content h4 {
    font-weight: bold; /* Negrita */
    color: #1f1f91; /* Azul fuerte */
}

/* Negrita para los textos dentro de las secciones */
#content p, #content label {
    font-weight: bold;
    color: #333;
}

/*panel de usuario*/
/* Estilos generales del panel de usuario */
                    .sidebar {
                        background: rgba(141, 228, 255, 0.41);
                        padding: 20px;
                        border-radius: 10px;
                        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
                        font-weight: bold; /* Negrita en todo el panel */
                    }

                    /* Estilos para los enlaces del menú */
                    .sidebar a {
                        display: block;
                        text-decoration: none;
                        color: #333;
                        font-size: 16px;
                        font-weight: bold; /* Negrita */
                        padding: 10px;
                        border-radius: 5px;
                        margin-bottom: 5px;
                        transition: background-color 0.3s ease-in-out;
                    }

                    /* Efecto al pasar el mouse */
                    .sidebar a:hover, 
                    .sidebar a.active {
                        background-color: #1f1f91;
                        color: white;
                    }

                    /* Estilos para los títulos y nombres del usuario */
                    .sidebar h5 {
                        font-weight: bold; /* Negrita */
                        color: #1f1f91;
                        margin-top: 10px;
                    }

                    /* Imagen de perfil */
                    .profile-pic {
                        width: 80px;
                        height: 80px;
                        border-radius: 50%;
                        object-fit: cover;
                        margin-bottom: 10px;
                    }

                    /* Separador */
                    .sidebar hr {
                        border: 1px solid #ddd;
                        margin: 15px 0;
                    }


    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mt-3">Cuenta</h2>
    <p class="text-center"><a href="index.php">Home</a> | Cuenta</p>

    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="sidebar">
                <div class="text-center">
                    <img src="<?= $foto_perfil ?>" alt="Usuario" class="profile-pic">
                    <h5><?= htmlspecialchars($nombre . " " . $apellidos) ?></h5>
                    <a href="#" class="menu-item" data-page="perfil">Ver el perfil</a>
                </div>
                <hr>
                <a href="#" class="menu-item" data-page="cuenta">Cuenta</a>
                <a href="#" class="menu-item" data-page="cambiar_contrasena">Cambiar la contraseña</a>
                <a href="#" class="menu-item" data-page="mi_direccion">Mi Dirección de Entrega</a>
                <a href="#" class="menu-item" data-page="mis_ordenes">Mis Órdenes</a>
                <a href="#" class="menu-item" data-page="dni">DNI</a>
                <a href="#" class="menu-item" data-page="ruc">RUC</a>
                <a href="#" class="menu-item" data-page="recomendacion">Recomendacion Importantes</a>
                <a href="#" class="menu-item" data-page="documentos">Documentos Importantes</a>
                <a href="nuevo_pedido.php" target="_blank">Nuevo Pedido</a>
                <a href="logout.php" class="text-danger">Salir</a>
            </div>
        </div>

        <!-- Contenido dinámico -->
        <div class="col-md-9">
            <div id="content" class="content">
                <h4>Bienvenido a tu panel de usuario</h4>
                <p>Selecciona una opción del menú para gestionar tu cuenta.</p>
            </div>
        </div>
    </div>
</div>

<script src="js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include '../footer.php'; ?>
