<?php
session_start();
include '../config/conexion.php';
?>

<?php include '../header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT id, nombre, password, foto_perfil FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $nombre, $hashed_password, $foto_perfil);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['usuario_id'] = $id;
            $_SESSION['usuario_nombre'] = $nombre;
            $_SESSION['usuario_foto'] = $foto_perfil ?? 'user.png'; // Si no hay foto, usa una por defecto.
            header("Location: dashboard.php"); 
            exit();
        } else {
            $_SESSION['error'] = "Contraseña incorrecta.";
        }
    } else {
        $_SESSION['error'] = "El usuario no existe.";
    }

    $stmt->close();
    $conn->close();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Perucho Currier</title>
    <style>
        body {
            display: flex;
            background: url('../img/vuelo.jpg') no-repeat center center fixed;
            background-size: cover;
            flex-direction: column;
            justify-content: space-between;
            min-height: 100vh;
            margin: 0;
        }
        main {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .form-container {
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0px 4px 15px rgba(175, 95, 95, 0.2);
            width: 500px;
            max-width: 90%;
            text-align: center;
        }
        h2 {
            color:rgb(0, 0, 0);
            font-size: 26px;
            margin-bottom: 20px;
        }
        input {
            width: calc(100% - 20px);
            padding: 12px;
            margin: 15px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 18px;
            height: 55px;
        }
        button {
            background:rgb(113, 233, 33);
            color: white;
            padding: 16px;
            border: none;
            width: 100%;
            border-radius: 8px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            transition: 0.3s;
            height: 55px;
        }
        button:hover {
            background:rgb(247, 233, 50);
            transform: scale(1.05);
        }
        .error {
            color: red;
            margin-top: 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
<main>
    <div class="form-container">
        <h2>Iniciar Sesión</h2>

        <?php if (isset($_SESSION['error'])): ?>
            <p class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Correo Electrónico" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Ingresar</button>
        </form>
        <p>¿No tienes una cuenta? <a href="registro.php">Regístrate aquí</a></p>
        <form action="enviar_recuperacion.php" method="POST">
    <label for="email">Ingresa tu correo electrónico:</label>
    <input type="email" name="email" required>
    <button type="submit">Enviar enlace de recuperación</button>
</form>

    </div>
    
</main>
</body>
</html>

<?php include '../footer.php'; ?>
