<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Pedido</title>
    <link rel="stylesheet" href="styles.css">
    <style>
    body {
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #ff0000, #0000ff); /* Degradado rojo a azul */
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
}

.form-container {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
    width: 450px; /* Un poco más compacto */
    max-width: 90%;
    text-align: left;
    position: relative;
    left: -50px; /* Ligeramente a la izquierda */
}

h2 {
    color:rgb(44, 7, 7);
    font-size: 24px;
    margin-bottom: 15px;
    text-align: center;
}

label {
    font-weight: bold;
    font-size: 14px;
    display: block;
    margin-top: 10px;
}

input, textarea, select {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

textarea {
    resize: vertical;
    height: 80px;
}

button {
    background: #ff0000; /* Rojo vivo */
    color: white;
    padding: 12px;
    border: none;
    width: 100%;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: 0.3s ease-in-out;
}

button:hover {
    background: #cc0000;
    transform: scale(1.05);
}

.file-input {
    border: 2px dashed #0000ff; /* Azul */
    padding: 10px;
    text-align: center;
    cursor: pointer;
}

.file-input input {
    display: none;
}

</style>
</head>
<body>
    <div class="form-container">
        <h2>Nuevo Pedido</h2>
        <form action="procesar_pedido.php" method="POST" enctype="multipart/form-data">
            <label>¿En qué web compraste? *</label>
            <input type="text" name="web_compra" required>

            <label>¿Qué productos estás comprando? *</label>
            <input type="text" name="productos" required>

            <label>¿Cuál es el precio de tu compra? *</label>
            <input type="number" name="precio" required>

            <label>Indica los números de seguimiento (El TRACKING de tu compra)*</label>
            <input type="text" name="seguimiento" required>

            <label>¿Cuándo llegan tus compras a nuestro almacén? *</label>
            <input type="date" name="fecha_llegada" required>

            <label>Subir factura de compra *</label>
            <input type="file" name="factura" accept=".pdf,.doc,.docx,.xls,.xlsx" required>

            <button type="submit">Realizar el pedido</button>
        </form>
    </div>
</body>
</html>
