
<?php
include '../config/conexion.php';
// Conexión a la BD

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar datos del formulario
    $email = $_POST['email'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $telefono = $_POST['telefono'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encriptar contraseña
    $dni_numero = $_POST['dni'];
    $dni_direccion = $_POST['direccion_dni'];
    $dni_provincia = $_POST['provincia_dni'];
    $ruc_numero = $_POST['numero_ruc'] ?? null;
    $ruc_razon_social = $_POST['razon_social'] ?? null;
    $ruc_direccion = $_POST['direccion_ruc'] ?? null;
    $ruc_provincia = $_POST['provincia_ruc'] ?? null;

    // Subir archivos (DNI y RUC PDF)
    $dni_pdf = null;
    if (!empty($_FILES['dni_pdf']['name'])) {
        $dni_pdf = "../uploads/" . basename($_FILES['dni_pdf']['name']);
        move_uploaded_file($_FILES['dni_pdf']['tmp_name'], "../" . $dni_pdf);
    }

    $ruc_pdf = null;
    if (!empty($_FILES['ruc_pdf']['name'])) {
        $ruc_pdf = "../uploads/" . basename($_FILES['ruc_pdf']['name']);
        move_uploaded_file($_FILES['ruc_pdf']['tmp_name'], "../" . $ruc_pdf);
    }

    // Insertar datos en la base de datos
    $sql = "INSERT INTO usuarios (email, nombre, apellidos, movil, password, dni_numero, dni_direccion, dni_provincia, dni_pdf, ruc_numero, ruc_razon_social, ruc_direccion, ruc_provincia, ruc_pdf)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssss", $email, $nombre, $apellidos, $telefono, $password, $dni_numero, $dni_direccion, $dni_provincia, $dni_pdf, $ruc_numero, $ruc_razon_social, $ruc_direccion, $ruc_provincia, $ruc_pdf);

    if ($stmt->execute()) {
        echo "<script>alert('Registro exitoso'); window.location.href='../public/login.php';</script>";

    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Acceso no permitido.";
}
?>
