<?php
// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener datos actuales del usuario
$sql = "SELECT nombre, apellidos FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
$stmt->close();
$conexion->close();
?>

<h4>Cuenta</h4>
<form id="formActualizarCuenta">
    <label>Nombre de usuario</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['nombre'] ?? ''); ?>" disabled>

    <label>Nombre</label>
    <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario['nombre'] ?? ''); ?>" required>

    <label>Apellidos</label>
    <input type="text" name="apellidos" class="form-control" value="<?php echo htmlspecialchars($usuario['apellidos'] ?? ''); ?>" required>

    <button type="submit" class="btn btn-success btn-custom">Actualizar la cuenta</button>
</form>
<div id="mensajeCuenta"></div>
