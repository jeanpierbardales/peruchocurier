<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentos Importantes</title>
    <style>
        .container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .documentos-wrapper {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .doc-box {
            width: 250px;
            padding: 20px;
            border-radius: 10px;
            background:rgb(231, 134, 134);
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: 0.3s;
            
        }

        .doc-box:hover {
            background:rgb(154, 231, 130);
            transform: scale(1.05);
            text-align: center;
        }

        .doc-box img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }

        .doc-box a {
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            color: #1f1f91;
            display: block;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>📄 Acceso Directo a Documentos Importantes</h2>
    <p>En esta sección encontrarás documentos y archivos importantes que podrás revisar y usar en tus despachos y servicios con Perucho Courrier.</p>

        <div class="doc-box">
            <img src="../img/prohibido.png" alt="Productos Restringidos">
            <a href="../documentos/pd.pdf" download>📥 Descargar Lista de Productos Restringidos</a>
        </div>
    </div>
</div>
</body>
</html>
