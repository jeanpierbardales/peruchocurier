<?php
// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener datos actuales del usuario
$sql = "SELECT ruc_numero, ruc_razon_social, ruc_direccion, ruc_provincia, ruc_pdf FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
$stmt->close();
$conexion->close();
?>

<h4>Datos del RUC</h4>
<form id="formRUC" enctype="multipart/form-data">
    <label>Número de RUC *</label>
    <input type="text" name="ruc_numero" class="form-control" value="<?php echo htmlspecialchars($usuario['ruc_numero'] ?? ''); ?>" required>

    <label>Razón Social *</label>
    <input type="text" name="ruc_razon_social" class="form-control" value="<?php echo htmlspecialchars($usuario['ruc_razon_social'] ?? ''); ?>" required>

    <label>Dirección *</label>
    <input type="text" name="ruc_direccion" class="form-control" value="<?php echo htmlspecialchars($usuario['ruc_direccion'] ?? ''); ?>" required>

    <label>Provincia *</label>
    <input type="text" name="ruc_provincia" class="form-control" value="<?php echo htmlspecialchars($usuario['ruc_provincia'] ?? ''); ?>" required>

    <label>Subir RUC (PDF) *</label>
    <input type="file" name="ruc_pdf" class="form-control" accept=".pdf">

    <?php if (!empty($usuario['ruc_pdf'])): ?>
        <p>Archivo actual: <a href="<?php echo htmlspecialchars($usuario['ruc_pdf']); ?>" target="_blank">Ver archivo</a></p>
    <?php endif; ?>

    <button type="submit" class="btn btn-success">Guardar RUC</button>
</form>

<div id="mensajeRUC"></div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ Script de RUC cargado correctamente");

    const form = document.querySelector("#formRUC");
    if (!form) {
        console.error("❌ Formulario no encontrado");
        return;
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        const formData = new FormData(form);

        fetch("acciones/guardar_ruc.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById("mensajeRUC").innerHTML = 
                `<div class='alert alert-${data.status === 'success' ? 'success' : 'danger'}'>
                    ${data.message}
                </div>`;
        })
        .catch(error => {
            console.error("⚠️ Error en la solicitud:", error);
            document.getElementById("mensajeRUC").innerHTML = 
                "<div class='alert alert-danger'>Error en la solicitud.</div>";
        });
    });
});
</script>
