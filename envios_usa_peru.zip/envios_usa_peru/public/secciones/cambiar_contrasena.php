<?php

// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    echo "<div class='alert alert-danger'>Debes iniciar sesión.</div>";
    exit();
}
?>

<h3>Cambiar Contraseña</h3>
<form id="formCambiarContrasena" method="post">
    <div class="mb-3">
        <label>Contraseña actual</label>
        <input type="password" name="contrasena_actual" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Nueva contraseña</label>
        <input type="password" name="nueva_contrasena" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Confirmar contraseña</label>
        <input type="password" name="confirmar_contrasena" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Actualizar Contraseña</button>
</form>

<div id="mensajeCambio"></div>

<script>
document.getElementById("formCambiarContrasena").addEventListener("submit", function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch("../acciones/procesar_cambio_contrasena.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json()) // Convertir respuesta en JSON
    .then(data => {
        const mensajeDiv = document.getElementById("mensajeCambio");
        if (data.status === "success") {
            mensajeDiv.innerHTML = "<div class='alert alert-success'>" + data.message + "</div>";
            document.getElementById("formCambiarContrasena").reset(); // Limpiar formulario
        } else {
            mensajeDiv.innerHTML = "<div class='alert alert-danger'>" + data.message + "</div>";
        }
    })
    .catch(error => {
        document.getElementById("mensajeCambio").innerHTML = "<div class='alert alert-danger'>Error en la solicitud.</div>";
    });
});
</script>
