<?php
// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener datos del usuario
$sql = "SELECT dni_numero, dni_direccion, dni_provincia FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
$stmt->close();
$conexion->close();
?>

<h4>Datos del DNI</h4>
<form>
    <label>Número de DNI</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['dni_numero'] ?? ''); ?>" disabled>

    <label>Dirección DNI</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['dni_direccion'] ?? ''); ?>" disabled>

    <label>Provincia</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['dni_provincia'] ?? ''); ?>" disabled>
</form>
