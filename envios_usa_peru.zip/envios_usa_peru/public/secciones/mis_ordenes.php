<?php
include '../../config/conexion.php'; // Asegúrate de que la ruta es correcta
session_start(); // Iniciar sesión si no está activa

if (!isset($_SESSION['usuario_id'])) {
    die("Acceso denegado. Debes iniciar sesión.");
}

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT id, web_compra, productos, precio, seguimiento, fecha_llegada,codigo_pago , estado FROM pedidos WHERE usuario_id = ?";
$stmt = $conn->prepare($sql); // 🔥 Cambiado de $conexion a $conn

if (!$stmt) {
    die("Error en la consulta SQL: " . $conn->error); // 🔥 Cambiado de $conexion->error a $conn->error
}

$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Órdenes - Perucho Courier</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <h2>Mis Órdenes</h2>
    <p>Aquí puedes ver el estado de tus pedidos.</p>

    <?php if ($result->num_rows > 0): ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Web de Compra</th>
                    <th>Productos</th>
                    <th>Precio ($)</th>
                    <th>N° Seguimiento</th>
                    <th>Llegada a Almacén</th>
                    <th>Código de Pago</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($pedido = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($pedido['id']) ?></td>
                        <td><?= htmlspecialchars($pedido['web_compra']) ?></td>
                        <td><?= htmlspecialchars($pedido['productos']) ?></td>
                        <td><?= htmlspecialchars($pedido['precio']) ?></td>
                        <td><?= htmlspecialchars($pedido['seguimiento']) ?></td>
                        <td><?= htmlspecialchars($pedido['fecha_llegada']) ?></td>
                        <td><strong><?= htmlspecialchars($pedido['codigo_pago']) ?></strong></td>
                        <td>
                             <?php 
                                $estado = $pedido['estado'];
    
                                $estados = [
                                            "pendiente"   => ["badge bg-warning text-dark", "Pendiente"],
                                            "procesando"  => ["badge bg-primary", "Procesando"],
                                            "enviado"     => ["badge bg-info text-dark", "Enviado"],
                                            "entregado"   => ["badge bg-success", "Entregado"],
                                            "finalizado"   => ["badge bg-success", "Finalizado"]
                                             ];

                                if (isset($estados[$estado])): ?>
                                <span class="<?= $estados[$estado][0] ?>"><?= $estados[$estado][1] ?></span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Desconocido</span>
                            <?php endif; ?>
                        </td>

                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">
            <h4 class="alert-heading">Mis Órdenes</h4>
            <p>Aún no tienes ningún pedido registrado. Registra uno nuevo en la opción de <a href="../public/nuevo_pedido.php">Nuevo Pedido</a>.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
