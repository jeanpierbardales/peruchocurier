

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recomendaciones Importantes</title>
    <style>
        /* 🔹 Estilos para Recomendaciones Importantes */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .titulo-recomendaciones {
            text-align: center;
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #1f1f91;
        }

        .recomendaciones-container ul {
            font-size: 20px;
            color: #333;
            line-height: 1.8;
            list-style: none;
            padding: 0;
        }

        .recomendaciones-container ul li {
            margin-bottom: 10px;
            padding-left: 30px;
            position: relative;
        }

        .recomendaciones-container ul li::before {
            content: "✔️";
            position: absolute;
            left: 0;
            color: green;
            font-weight: bold;
            font-size: 14px;
        }

        .contacto {
            text-align: center;
            font-size: 22px;
            margin-top: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="titulo-recomendaciones">📌 RECOMENDACIONES IMPORTANTES</h2>

    <div class="recomendaciones-container">
        <ul>
            <li>✅ Cada vez que uses nuestro servicio Perucho, coloca de consignatario: <b>"perucho" + NOMBRE + APELLIDO</b>. Ejemplo: <b>perucho Jeanpier Lujan Carrion</b>.</li>
            <li>✅ Sube tu pedido a la plataforma solo cuando tengas los <b>tracking number</b> completos.</li>
            <li>✅ El tiempo de tránsito es de <b>5 a 7 días hábiles</b> desde que la compra ingrese a nuestro almacén en Miami.</li>
            <li>✅ Tienes un máximo de <b>7 días</b> para mandar tus instrucciones de embarque o consolidación. Luego, se genera un cobro adicional diario de <b>$0.25</b> o un pago de <b>$20</b> en el primer mes. (POR CADA TRACKING).</li>
            <li>✅ Desde junio 2021, todo despacho que salga en <b>CANAL ROJO</b> tendrá un pago adicional de <b>$5.9</b> por gestión de aforo.</li>
            <li>✅ En una guía de embarque se pueden juntar hasta <b>5 trackings</b>, si son más, se cobra <b>$1</b> por cada adicional.</li>
            <li>✅ Horario de recepción de productos en Miami: <b>Lunes a Viernes de 10 am a 5 pm</b>.</li>
            <li>✅ El reempaque por etiquetas de restricción tiene un costo adicional de <b>$25</b>.</li>
            <li>✅ Sin RUC propio puedes realizar hasta <b>3 pedidos al año</b>.</li>
            <li>✅ Si deseas devolver tu producto desde Miami, el costo es de <b>$25</b>.</li>
            <li>✅ Plazo máximo de <b>14 días</b> para cancelar los servicios de Perucho y recoger los productos. De lo contrario, penalidad de <b>S/.10</b> por cada semana adicional.</li>
            <li>✅ Algunos productos están <b>restringidos</b>, si no pueden ser embarcados, deberás retirarlos o declararlos en abandono.</li>
        </ul>

        <p class="contacto">
            📞 Para cualquier duda, puedes llamarnos al <b>9967-929-967- Edwin</b> 🤗
        </p>
    </div>
</div>

</body>
</html>
