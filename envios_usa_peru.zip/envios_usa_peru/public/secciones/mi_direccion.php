<?php
// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "perucho_currier");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener datos de la dirección
$sql = "SELECT nombre, apellidos, direccion, ciudad, provincia, codigo_postal, telefono FROM direcciones WHERE usuario_id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$direccion = $result->fetch_assoc();
$stmt->close();

// Obtener el email del usuario
$sql_usuario = "SELECT email FROM usuarios WHERE id = ?";
$stmt_usuario = $conexion->prepare($sql_usuario);
$stmt_usuario->bind_param("i", $usuario_id);
$stmt_usuario->execute();
$result_usuario = $stmt_usuario->get_result();
$usuario = $result_usuario->fetch_assoc();
$email = $usuario['email'] ?? ''; // Asignar email del usuario
$stmt_usuario->close();
$conexion->close();
?>

<h4>Mi Dirección de Entrega</h4>
<form id="formDireccion">
    <label>Nombre *</label>
    <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($direccion['nombre'] ?? ''); ?>" required>

    <label>Apellidos *</label>
    <input type="text" name="apellidos" class="form-control" value="<?php echo htmlspecialchars($direccion['apellidos'] ?? ''); ?>" required>

    <label>Nombre de la empresa (opcional)</label>
    <input type="text" name="empresa" class="form-control">

    <label>País/Región *</label>
    <input type="text" name="pais" class="form-control" value="Perú" disabled>

    <label>Dirección de la calle *</label>
    <input type="text" name="direccion" class="form-control" value="<?php echo htmlspecialchars($direccion['direccion'] ?? ''); ?>" required>

    <label>Localidad / Ciudad *</label>
    <input type="text" name="ciudad" class="form-control" value="<?php echo htmlspecialchars($direccion['ciudad'] ?? ''); ?>" required>

    <label>Región / Provincia *</label>
    <input type="text" name="provincia" class="form-control" value="<?php echo htmlspecialchars($direccion['provincia'] ?? ''); ?>" required>

    <label>Código postal *</label>
    <input type="text" name="codigo_postal" class="form-control" value="<?php echo htmlspecialchars($direccion['codigo_postal'] ?? ''); ?>" required>

    <label>Teléfono *</label>
    <input type="text" name="telefono" class="form-control" value="<?php echo htmlspecialchars($direccion['telefono'] ?? ''); ?>" required>

    <label>Dirección de correo electrónico *</label>
    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" disabled>

    <button type="submit" class="btn btn-success">Guardar Dirección</button>
</form>
<div id="mensajeDireccion"></div>




