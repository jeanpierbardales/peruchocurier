<?php
include '../../config/conexion.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    echo "Acceso no autorizado.";
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener los datos del usuario
$sql = "SELECT nombre, apellidos, dni_numero, email, foto_perfil FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error en la consulta: " . $conn->error);
}

$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Foto de perfil (si no tiene, usa la predeterminada)
$foto_perfil = !empty($usuario['foto_perfil']) ? "../" . $usuario['foto_perfil'] : "../img/user.png";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
</head>
<body>

<div class="perfil-container">
    <img src="<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto de perfil">
    <h2><?php echo htmlspecialchars($usuario['nombre'] . " " . $usuario['apellidos']); ?></h2>
    <p><strong>DNI:</strong> <?php echo htmlspecialchars($usuario['dni_numero']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
</div>

</body>
</html>


