<?php
?>

<?php include '../header.php'; ?> 

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosotros - Perucho Currier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color:rgb(231, 226, 203);

        }
        .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 1200px;
            margin: auto;
            padding: 50px 20px;
        }
        .text-content {
            width: 50%;
        }
        .text-content span {
            font-size: 22px;
            color: #d9534f;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        .text-content span::before {
            content: "";
            width: 40px;
            height: 2px;
            background-color: #d9534f;
            margin-right: 10px;
        }
        .text-content h1 {
            font-size: 60px;
            font-weight: bold;
            color: #002f6c;
            margin: 10px 0;
        }
        .text-content h1 .red {
            color: #d9534f;
        }
        .text-content p {
            font-size: 22px;
            color: #555;
            line-height: 1.8;
            font-weight: bold;
        }
        .text-content p strong {
            font-size: 28px;
            font-weight: bold;
        }
        .image-container {
            width: 50%;
            position: relative;
            display: flex;
            justify-content: flex-end;
        }
        .image-container img {
            width: 90%;
            border-radius: 10px;
        }
        .small-image {
            position: absolute;
            bottom: -20px;
            left: -50px;
            width: 200px;
            border-radius: 8px;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.2);
        }
        .founder-card {
            display: flex;
            align-items: center;
            background: #f1f3f5;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            width: 300px;
        }
        .founder-card img {
            width: 70px;
            height: 90px;
            border-radius: 50%;
            margin-right: 15px;
        }
        .founder-card .info {
            font-size: 18px;
            font-weight: bold;
        }
        .founder-card .info strong {
            display: block;
            color: #002f6c;
        }
        .founder-card .info span {
            color: #555;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <section class="container">
        <div class="text-content">
            <span>Bienvenido a</span>
            <h1>Perucho Courier</h1>
            <p>
            Perucho Courier es una empresa dedicada a la importación de productos en general de China y Estados Unidos a Perú,
             con más de 10 años de experiencia en el sector. Nos enfocamos en brindar una experiencia rápida, segura y sin complicaciones a nuestros clientes en la recepción de sus compras internacionales. Contamos con alianzas estratégicas con empresas nacionales e internacionales de gran trayectoria, lo que nos permite optimizar los tiempos de desaduanaje y entrega, garantizando un servicio eficiente y confiable. Nos esforzamos por ofrecer un servicio de excelencia tanto a clientes corporativos como a usuarios individuales, adaptándonos a las tendencias del e-commerce para satisfacer las nuevas necesidades del mercado. Nuestra visión es consolidarnos como un líder en logística de importaciones y seguir innovando en soluciones para nuestros clientes.
             🚀 Perucho Courier: Importa fácil, rápido y seguro desde EE.UU.
            <div class="founder-card">
                <img src="../img/founder.jpg" alt="Fundador">
                <div class="info">
                    <strong>Edwin Sanchez </strong>
                    <span>Fundador</span>
                </div>
            </div>
        </div>
        <div class="image-container">
            <img src="../img/captura.png" alt="Imagen Principal">

        </div>
    </section>
</body>
</html>

<?php include '../footer.php'; ?>
