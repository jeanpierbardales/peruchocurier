document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ Script cargado correctamente");

    const menuItems = document.querySelectorAll(".menu-item");
    const contentContainer = document.querySelector("#content");

    menuItems.forEach(item => {
        item.addEventListener("click", function (e) {
            e.preventDefault();
            console.log("📌 Clic en:", this.getAttribute("data-page"));

            menuItems.forEach(link => link.classList.remove("active"));
            this.classList.add("active");

            const page = this.getAttribute("data-page");
            console.log(`🔄 Cargando: secciones/${page}.php`);

            fetch(`secciones/${page}.php`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`❌ Error ${response.status}: No se pudo cargar la sección.`);
                    }
                    return response.text();
                })
                .then(data => {
                    console.log("✅ Sección cargada correctamente");
                    contentContainer.innerHTML = data;

                    setTimeout(() => {
                        switch (page) {
                            case "cambiar_contrasena":
                                setupForm("#formCambiarContrasena", "acciones/procesar_cambio_contrasena.php", "#mensajeCambio");
                                break;
                            case "cuenta":
                                setupForm("#formActualizarCuenta", "acciones/actualizar_cuenta.php", "#mensajeCuenta");
                                break;
                            case "mi_direccion":
                                setupForm("#formDireccion", "acciones/guardar_direccion.php", "#mensajeDireccion");
                                break;
                            case "perfil":
                                setupProfileUpdate();
                                break;
                            case "nuevo_pedido":
                                setupForm("#formNuevoPedido", "procesar_pedido.php", "#mensajePedido", true);
                                break;
                            case "admin_pedidos":
                                setupAdminActions();
                                break;
                            default:
                                console.log("⚠️ No hay acción específica para esta sección.");
                        }
                    }, 500);
                })
                .catch(error => {
                    console.error("⚠️ Error al cargar:", error);
                    contentContainer.innerHTML = `<div class='alert alert-danger'>Error al cargar la sección: ${error.message}</div>`;
                });
        });
    });

    function setupForm(formSelector, actionUrl, messageContainer, redirectToOrders = false) {
        const form = document.querySelector(formSelector);
        if (!form) {
            console.warn(`⚠️ No se encontró el formulario ${formSelector}`);
            return;
        }

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch(actionUrl, {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                document.querySelector(messageContainer).innerHTML = `<div class='alert alert-${data.status === 'success' ? 'success' : 'danger'}'>${data.message}</div>`;
                
                if (data.status === "success" && redirectToOrders) {
                    setTimeout(() => {
                        window.location.href = "dashboard.php";
                    }, 2000);
                }
            })
            .catch(error => {
                document.querySelector(messageContainer).innerHTML = "<div class='alert alert-danger'>Error en la solicitud.</div>";
                console.error("⚠️ Error en la solicitud:", error);
            });
        });
    }

    function setupProfileUpdate() {
        const form = document.querySelector("#formActualizarPerfil");
        if (!form) return;

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch("acciones/actualizar_perfil.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                document.querySelector("#mensajePerfil").innerHTML = `<div class='alert alert-${data.status === 'success' ? 'success' : 'danger'}'>${data.message}</div>`;
            })
            .catch(error => {
                document.querySelector("#mensajePerfil").innerHTML = "<div class='alert alert-danger'>Error en la solicitud.</div>";
                console.error("⚠️ Error en la solicitud:", error);
            });
        });
    }

    function setupAdminActions() {
        document.querySelectorAll(".cambiar-estado").forEach(select => {
            select.addEventListener("change", function () {
                const pedidoId = this.dataset.id;
                const nuevoEstado = this.value;

                fetch("acciones/actualizar_estado.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ id: pedidoId, estado: nuevoEstado })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        alert("✅ Estado actualizado correctamente");
                        location.reload();
                    } else {
                        alert("❌ Error al actualizar el estado");
                    }
                })
                .catch(error => {
                    console.error("⚠️ Error al actualizar estado:", error);
                });
            });
        });

        document.querySelectorAll(".eliminar-pedido").forEach(button => {
            button.addEventListener("click", function () {
                if (!confirm("❗ ¿Estás seguro de eliminar este pedido?")) return;
                
                const pedidoId = this.dataset.id;
                
                fetch("acciones/eliminar_pedido.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ id: pedidoId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        alert("🗑 Pedido eliminado correctamente");
                        location.reload();
                    } else {
                        alert("❌ Error al eliminar el pedido");
                    }
                })
                .catch(error => {
                    console.error("⚠️ Error al eliminar pedido:", error);
                });
            });
        });

        document.querySelectorAll(".ver-historial").forEach(button => {
            button.addEventListener("click", function () {
                const usuarioId = this.dataset.id;
                
                fetch("acciones/ver_historial.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ usuario_id: usuarioId })
                })
                .then(response => response.text())
                .then(data => {
                    document.querySelector("#historialPedidos").innerHTML = data;
                })
                .catch(error => {
                    console.error("⚠️ Error al obtener historial:", error);
                });
            });
        });
    }
});
