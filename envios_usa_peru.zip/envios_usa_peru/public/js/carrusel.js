document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ Carrusel de desvanecimiento cargado correctamente");

    const images = document.querySelectorAll(".carousel img");
    let currentIndex = 0;
    const totalImages = images.length;

    function changeImage() {
        images.forEach(img => img.classList.remove("active")); // Ocultamos todas
        images[currentIndex].classList.add("active"); // Mostramos la actual

        currentIndex = (currentIndex + 1) % totalImages; // Pasamos a la siguiente
    }

    setInterval(changeImage, 3000); // Cambio cada 3 segundos
    changeImage(); // Iniciar la primera imagen activa
});
