<?php
include '../header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $producto = htmlspecialchars($_POST['producto']);
    $peso = floatval($_POST['peso']);
    $precio_producto = floatval($_POST['precio_producto']);
    $tarifa_por_kg = 9.5;
    $guia_operativa = 9;

    $costo_envio = ($peso * $tarifa_por_kg) + $guia_operativa;
    $costo_total = $precio_producto + $costo_envio;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Envío</title>
    <style>
       body {
    font-family: Arial, sans-serif;
    background: url('../img/vuelo.jpg') no-repeat center center fixed;
    background-size: cover;
    color: white;
    margin: 0;
    padding: 0;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

    .container {
        display: flex;
        justify-content: space-between;
        gap: 20px;
        max-width: 1000px;
        margin: 0 auto; /* Centra el contenedor en la página */
        width: 90%;
        background: rgba(221, 241, 107, 0.9);
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
        color: black;
        flex-grow: 1; /* Permite que el contenedor principal crezca y empuje el footer hacia abajo */
    }

footer {
    background: purple;
    color: white;
    text-align: center;
    padding: 20px;
    width: 100%;
    margin-top: auto; /* Hace que el footer se mantenga abajo */
}


        .tarifario, .formulario {
            flex: 1;
            padding: 45px;
            background: rgb(249, 253, 183);
            border-radius: 8px;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            font-weight: bold;
        }

        .formulario {
            background: white;
            width: 350px;
            padding: 50px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 4px 10px rgb(200, 10, 218);
            text-align: center;
            font-weight: bold;
        }

        h2 {
            text-align: center;
            color:rgb(193, 6, 218);
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            background-color: rgb(70, 150, 255);
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 18px;
        }

        button:hover {
            background-color: #004aad;
        }

        .resultado {
            margin-top: 20px;
            padding: 15px;
            background:rgb(197, 202, 206);
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }

        .resultado h3 {
            color: #002f6c;
        }
        
    </style>
</head>

<body>

<div class="container">
    <div class="tarifario">
        <h2>Mas de Nuestros Servicios</h2>
        <p>✔️ Al superar los 200 dólares, la aduana cobra un impuesto del 25%.</p>
        <p>✔️ Nuestra calculadora  cotiza el servicio  en dolares, sin embargo puedes cancelar  en soles al tipo de cambio del dia.  </p>
        <p>✔️ Puedes importar hasta 3 veces. Para una cuarta importación, deberás tramitar tu RUC 10 o tener RUC 20 como empresa. En ambos casos, es factible. El RUC se tramita vía web o presencial. Solo debes tener un recibo de servicios.</p>
        <p>✔️ Después de 30 días sin retiro, hay un cargo de $30 por almacenaje.</p>
        <p>✔️ Se recomienda que tu compra no supere los 199.99 dólares para evitar el pago de impuestos ante la aduana de tu país. 
            Si este valor es superado, deberás considerar un pago adicional del 25% sobre el valor de tu compra.</p>
        <p>✔️ Distribuimos tus productos en diferentes guías, disminuyendo el costo global y evitando sobrecostos de tus importaciones. 
            Brindamos asesoría para el dominio de los reempaques y consolidados.</p>
    </div>

    <div class="formulario">
        <h2>Calcula tu Envío</h2>
        <form action="" method="POST">
            <label for="producto">¿Qué contiene tu compra?</label>
            <input type="text" name="producto" placeholder="Ejemplo: Zapatillas, Ropa, Accsesorios del Hogar" required>

            <label for="peso">Peso del paquete (KG):</label>
            <input type="number" step="0.01" name="peso" required>

            <label for="precio_producto">Precio del producto (USD):</label>
            <input type="number" step="0.01" name="precio_producto" required>

            <button type="submit">Calcular</button>
        </form>

        <?php if ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
        <div class="resultado">
            <h3>Detalle de costos</h3>
            <p><strong>Producto:</strong> <?php echo $producto; ?></p>
            <p><strong>Tarifa:</strong> $<?php echo number_format($tarifa_por_kg, 2); ?> por KG</p>
            <p><strong>Guía operativa:</strong> $<?php echo number_format($guia_operativa, 2); ?></p>
            <p><strong>Flete USA - Perú:</strong> $<?php echo number_format($costo_envio, 2); ?></p>
            <h3><strong>INVERSIÓN TOTAL:</strong> $<?php echo number_format($costo_total, 2); ?></h3>
        </div>
        <?php endif; ?>
    </div>
</div>

</body>
<section class="clientes-satisfechos">
    <h2>CLIENTES SATISFECHOS</h2>
    <div class="galeria">
        <img src="../img/uno.jpg" alt="Cliente feliz">
        <img src="../img/dos.jpg" alt="Cliente sonriente">
        <img src="../img/tres.jpg" alt="Entrega exitosa">
        <img src="../img/cuatro.jpg" alt="Paquete recibido">
        <img src="../img/cinco.jpg" alt="Buen servicio">
        <img src="../img/seis.jpg" alt="Cliente contento">
        <img src="../img/siete.jpg" alt="Entrega rápida">
        <img src="../img/ocho.jpg" alt="Satisfacción garantizada">
        <img src="../img/nueve.jpg" alt="Paquete sin problemas">
        <img src="../img/diez.jpg" alt="Servicio confiable">
        <img src="../img/once.jpg" alt="Recomendado">
        <img src="../img/doce.jpg" alt="Entrega sin inconvenientes">
        <img src="../img/trece.jpg" alt="Cliente recurrente">
        <img src="../img/siete.jpg" alt="Rápido y seguro">
        <iframe width="100%" height="450" src="https://www.youtube.com/embed/zlgaD9zLZI8" frameborder="0" allowfullscreen></iframe>
    </div>
            <style>
                        .clientes-satisfechos {
                    text-align: center;
                    margin-top: 40px;
                    padding: 20px;
                }

                .clientes-satisfechos h2 {
                    font-size: 45Px;
                    color: rgb(223, 2, 2);
                    margin-bottom: 20px;
                    font-weight: bold;
                }

                .galeria {
                    display: grid;
                    grid-template-columns: repeat(5, 1fr); /* 5 columnas */
                    grid-template-rows: repeat(4, auto);  /* 4 filas */
                    gap: 10px; /* Espaciado entre imágenes */
                    justify-content: center;
                    max-width: 80%;
                    margin: 0 auto;
                }

                .galeria img {
                    width: 100%;
                    height: auto;
                    border-radius: 8px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
                    transition: transform 0.3s ease-in-out;
                }

                .galeria img:hover {
                    transform: scale(1.1);
                }

    </style>
</section>

</html>

<?php include '../footer.php'; ?>
