

<?php include '../header.php';?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminos y Condiciones/Politica de privacidad - Perucho Courier</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            padding: 40px 20px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-size: 2rem;
            color: #1f1f91;
            text-align: center;
            margin-bottom: 20px;
        }

        h2 {
            font-size: 1.5rem;
            color: #ff7f00;
            margin-top: 25px;
            border-bottom: 3px solid #ff7f00;
            padding-bottom: 5px;
        }

        p {
            font-size: 1rem;
            line-height: 1.6;
        }

        .legal-box {
            background: #f8f9fa;
            padding: 15px;
            border-left: 5px solid #1f1f91;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul li::before {
            content: "✔️";
            margin-right: 8px;
            color: #1f1f91;
        }

        .btn-back {
            display: block;
            width: 100%;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Terminos y Condiciones/Politica de privacidad</h1>

    <div class="legal-box">
        <h2>1. Información General</h2>
        <p>Este sitio web es operado por <strong>Perucho Courier</strong>. Al acceder a esta página, usted acepta nuestros términos y condiciones.</p>
    </div>

    <div class="legal-box">
        <h2>2. Condiciones de Uso</h2>
        <ul>
            <li>El uso de este sitio implica la aceptación de nuestras políticas.</li>
            <li>Los servicios están sujetos a disponibilidad y cambios sin previo aviso.</li>
            <li>No nos hacemos responsables por problemas con terceros involucrados en el envío.</li>
        </ul>
    </div>

    <div class="legal-box">
        <h2>3. Protección de Datos</h2>
        <p>Su información será tratada con la máxima seguridad. No compartimos datos personales sin su consentimiento.</p>
    </div>

    <div class="legal-box">
        <h2>4. Enlace a Terceros</h2>
        <p> 
Nuestro sitio web puede contener enlaces a otros sitios de interes. Una vez que abandona nuestra pagina, Peru Courier no tiene control sobre el sitio al que es redirigido, por lo que no somos responsables de la proteccion de sus datos en esos sitios de terceros. 
Le recomendamos revisar las politicas de privacidad de dichos sitios para asegurarse de estar de acuerdo con sus terminos..</p>
    </div>

    <div class="legal-box">
        <h2>5. Condiciones de acceso</h2>
        <p> En general, el acceso al sitio web de Perucho Courier Perú es gratuito y no requiere registro previo.
Sin embargo, para hacer uso de algunas funcionalidades, el usuario puede necesitar registrarse, creando una cuenta de usuario con un nombre de usuario y una contraseña de acceso.
Es responsabilidad del usuario proporcionar únicamente información correcta, auténtica, válida, completa y actualizada, así como no revelar su nombre de usuario y contraseña a terceros.
Algunas partes de este sitio web ofrecen al usuario la opción de publicar comentarios en determinadas áreas.Chasqui Express Perú no consiente la publicación de contenidos de carácter discriminatorio, ofensivo o ilícito, o que infrinjan los derechos de autor o cualquier otro derecho de terceros.
La publicación de cualquier contenido por parte del usuario de este sitio web, incluidos los mensajes y comentarios, implica una licencia no exclusiva, irrevocable e irreversible para su uso, reproducción y publicación por parte de Chasqui Express Perú en su sitio web, plataformas de internet y aplicaciones, o incluso en otras plataformas, sin ninguna restricción o limitación.
</p>
    </div>

    <div class="legal-box">
        <h2>6. Plazos y modificaciones</h2>
        <p>El funcionamiento de este sitio web es por tiempo indefinido.
        La totalidad del sitio web o cada una de sus secciones podrá ser cerrada, suspendida o interrumpida unilateralmente por Chasqui Express Perú, en cualquier momento y sin previo aviso.</p>
    </div>

    <a href="index.php" class="btn btn-primary btn-back">Volver al Inicio</a>
</div>

</body>
</html>

<?php include '../footer.php'; ?>
