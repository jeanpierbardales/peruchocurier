<?php include '../config/conexion.php'; ?>
<?php include '../header.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Perucho Courier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../img/vuelo.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;
            margin: 0;
        }

        .form-container {
            background: white;
            padding: 25px;
            border-radius: 17px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 500px;
            text-align: center;
            margin-top: 40px; /* Ajusta este valor según lo necesites */
            margin-bottom: 20px;
            margin-left: -800px; /* Mueve el formulario a la izquierda */
        }
        
        .video-container {
            position: absolute;
            right: 60px;
            width: 900px;
            text-align: center;
        }

        h2 {
            margin-bottom: 10px;
            color: #1f1f91;
        }
        h3{
            margin-bottom: 10px;
            color: #1f1f91;
        }

        p {
            margin-bottom: 20px;
            color: #333;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap:  2px;
            text-align: left;
        }

        label {
            font-weight: bold;
            margin-top: 5px;
            display: block;
            font-size: 18px;
        }

        input, select {
            width: 80%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 12px;
        }

        .full-width {
            grid-column: span 2;
        }

        .file-input {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .file-input input {
            display: none;
        }

        .file-input label {
            background:rgb(51, 214, 29);
            color: white;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }

        .file-input label:hover {
            background: #15157e;
        }

        button {
            background:rgb(81, 219, 88);
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }

        button:hover {
            background:rgb(22, 0, 102);
        }

        header{
            text-align: center;
            margin-top: auto;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 20px;
            width: 100%;
            margin-top: auto;
        }
        footer h3{
            color:white;
        }
        h3{
            color: blue;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Crea tu cuenta en Perucho Courier</h2>
    <p>Rellena cuidadosamente la información requerida.</p>

    <form action="../public/procesar_registro.php" method="POST" enctype="multipart/form-data">
        <div class="form-grid">
            <div>
                <label for="email">E-mail</label>
                <input type="email" name="email" required>
            </div>

            <div>
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" required>
            </div>

            <div>
                <label for="apellidos">Apellidos</label>
                <input type="text" name="apellidos" required>
            </div>

            <div>
                <label for="telefono">Número de móvil</label>
                <input type="text" name="telefono" required>
            </div>

            <div>
                <label for="password">Contraseña</label>
                <input type="password" name="password" required>
            </div>

            <div>
                <label for="confirm_password">Confirmar Contraseña</label>
                <input type="password" name="confirm_password" required>
            </div>

            <h3 class="full-width">Datos del RUC (*Opcional)</h3>

            <div>
                <label for="numero_ruc">Número de RUC</label>
                <input type="text" name="numero_ruc">
            </div>

            <div>
                <label for="razon_social">Razón Social</label>
                <input type="text" name="razon_social">
            </div>

            <div>
                <label for="direccion_ruc">Dirección RUC</label>
                <input type="text" name="direccion_ruc">
            </div>

            <div>
                <label for="provincia_ruc">Provincia RUC</label>
                <input type="text" name="provincia_ruc">
            </div>

            <div class="file-input full-width">
                <label for="ruc_pdf">📂 Ficha RUC (Opcional - PDF)</label>
                <input type="file" name="ruc_pdf" id="ruc_pdf" accept=".pdf">
            </div>

            <h3 class="full-width">Datos del DNI</h3>

            <div>
                <label for="dni">Número de DNI</label>
                <input type="text" name="dni" required>
            </div>

            <div>
                <label for="direccion_dni">Dirección</label>
                <input type="text" name="direccion_dni" required>
            </div>

            <div>
                <label for="provincia_dni">Provincia</label>
                <input type="text" name="provincia_dni" required>
            </div>

            <div class="file-input full-width">
                <label for="dni_pdf">📂 Subir DNI (PDF)</label>
                <input type="file" name="dni_pdf" id="dni_pdf" accept=".pdf" required>
            </div>
        </div>

        <button type="submit">Registrar</button>
    </form>
    
</div>
<div class="video-container">
        <h3>¿Cómo registrarte?</h3>
        <iframe width="100%" height="450" src="https://www.youtube.com/embed/LrBmOwyu-zE?si=kcw-HPrJmGVtV-dh" frameborder="0" allowfullscreen></iframe>
    </div>
</body>
</html>

<?php include '../footer.php'; ?>
