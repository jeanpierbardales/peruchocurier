<?php

?>

<?php require_once '../header.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apoyo - Perucho Courier</title>
    <style>
            body {
                font-family: Arial, sans-serif;
                background: url('../img/tyron.jpg') no-repeat center center fixed;
                background-size: cover;
                color: white;
                margin: 0;
                padding: 0;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color:rgb(255, 255, 255);
            max-width: 1200px;
            font-size: 65px;
        }

        /* FAQ */
        .faq {
            margin-top: 30px;
        }

        .faq-item {
            border: 6px solid rgb(255, 255, 255);
            border-radius: 5px;
            margin-bottom: 10px;
            padding: 15px;
        }

        .faq-question {
            background-color:rgb(221, 199, 3); /* Fondo azul (puedes cambiarlo) */
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            font-weight: bold;
            color: rgb(255, 0, 0)
            ; /* Asegura que el texto sea blanco */
        }

        .faq-number {
            color: #ff6600;
            font-weight: bold;
            margin-right: 10px;
        }

        .faq-toggle {
            font-size: 18px;
            color: #ff6600;
        }

        .faq-answer {
            display: none;
            margin-top: 10px;
            font-size: 14px;
            color: #666;
            font-weight: bold;
        }

        /* Recomendaciones */
        .recomendaciones {
            margin-top: 50px;
            text-align: center;
        }

        .recomendaciones-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .recomendacion {
            background:rgb(230, 215, 86);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .recomendacion img {
            width: 40px;
            margin-bottom: 10px;
        }

        .recomendacion h3 {
            color: #002f6c;
            font-size: 16px;
            margin-bottom: 5px;
        }

        .recomendacion p {
            font-size: 14px;
            color: #666;
        }
        .recomendaciones-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* 2 columnas */
    gap: 20px;
    text-align: center;
}

.recomendacion {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(255, 253, 253, 0.1);
    transition: transform 0.3s ease-in-out;
}

.recomendacion:hover {
    transform: scale(1.05);
}

.recomendacion img {
    width: 120px; /* Aumenta el tamaño de los iconos */
    height: auto;
    margin-bottom: 10px;
}

.recomendacion h3 {
    font-size: 20px;
    color: #1f1f91;
}

.recomendacion p {
    font-size: 16px;
    color: #333;
}
.faq-answer{
    color: white; /* Cambia el color del texto a blanco */
    padding: 5px;
    font-size: 22px; /* Ajusta el tamaño de la fuente */
    line-height: 1.6; /* Mejora la legibilidad */
    background-color:rgba(211, 145, 2, 0.68);
}


    </style>
</head>
<body>

<div class="container">
    <h2>Preguntas Frecuentes</h2>
    <div class="faq">
        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">01</span>
                <h3>¿Qué servicio brinda Perucho Courier?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>Somos un courier, encargado de traer tus compras de USA - CHINA y que lo recibas en Perú.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">02</span>
                <h3>¿Puedo comprar en otros países y enviar la carga a Perucho Courier en USA?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>El servicio de Perucho Courier está disponible para compras en USA, Europa y todo el mundo. 
                    Solamente debes escribir tu dirección Perucho en el envío.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">03</span>
                <h3>¿Cuál es su tarifa?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>✔️ Tarifa Perucho Estandar: Kilo: $9.5/ Guía: $9</p>
                <p>✔️ Tarifa Perucho Comunidad: Kilo: $9 /Guía: $8.5</p>
                <p>✔️ Tarifa Perucho Premium: KG: $8.5 / Guía: $8</p>
                <p>Para mayor informacion comuniquese al Whatsapp Perucho Courier</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">04</span>
                <h3>¿Si soy nuev@, me asesoran en mi compra?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>Te ayudamos en tu compra de principio a fin, te recomendamos las mejores Páginas Web para comprar en USA.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">05</span>
                <h3>¿Puedo consolidar mis paquetes?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>Claro que sí, es uno de nuestros principales BENEFICIOS Efectúa tus compras en diferentes tiendas y nosotros juntamos
                     sus productos en una sola guía, ahorrando costos de envíos y optimizando sus importaciones..</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">06</span>
                <h3>Me encuentro en provincia ¿Puedo comprar?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>Realizamos envíos a todo el Perú. Toda Lima Metropolitana y provincias.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">07</span>
                <h3>¿Si el producto no llega a su destino, a quién debo reclamar?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>Si el producto no llega a nuestro almacen en USA, contacta a la tienda donde realizaste la compra y solicita el tracking number de dicho envío. 
                    Si el producto llega al almacen en USA pero no lo recibes en tu domicilio en un plazo de 5 días hábiles, contáctanos escribiendo a perucho.courier@gmail.com.</p>
            </div>
        </div>

        <div class="faq-item">
            <div class="faq-question">
                <span class="faq-number">08</span>
                <h3>¿Como se cuando mi pedido llega a Perú?</h3>
                <span class="faq-toggle">🔽</span>
            </div>
            <div class="faq-answer">
                <p>Cuando su compra llega a nuestro almacen le notificaremos al correo registrado.           
                    La notificacion sera enviada desde perucho.courier@gmail.com.Ademas, podra revisar el estado de su paquete en panel de pedidos.
                </p>
            </div>
        </div>
    </div>

    <h2>Recomendaciones</h2>
    <div class="recomendaciones">
        <div class="recomendaciones-grid">
            <div class="recomendacion">
                <img src="../img/icono-impuestos.jpg" alt="Evita Impuestos">
                <h3>EVITA IMPUESTOS</h3>
                <p>Compras menores a $200 en valor de producto no pagan impuestos.</p>
            </div>

            <div class="recomendacion">
                <img src="../img/icono-cantidad.png" alt="Cantidad">
                <h3>CANTIDAD</h3>
                <p>Con DNI máximo 3 compras al año y con RUC de manera ilimitada.</p>
            </div>

            <div class="recomendacion">
                <img src="../img/icono-unir.jpg" alt="Une tus pedidos">
                <h3>UNE TUS PEDIDOS</h3>
                <p>Puedes unir varias compras realizadas en páginas web y traerlas en un solo envío.</p>
            </div>

            <div class="recomendacion">
                <img src="../img/icono-china.jpg" alt="Comprar en China">
                <h3>COMPRAR EN CHINA</h3>
                <p>Puedes comprar desde China y enviarlo a USA para poder traerlo a Perú con nuestro servicio.</p>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const faqItems = document.querySelectorAll(".faq-item");

        faqItems.forEach((item) => {
            const question = item.querySelector(".faq-question");
            const answer = item.querySelector(".faq-answer");
            const toggle = item.querySelector(".faq-toggle");

            question.addEventListener("click", function () {
                const isOpen = answer.style.display === "block";

                document.querySelectorAll(".faq-answer").forEach((ans) => ans.style.display = "none");
                document.querySelectorAll(".faq-toggle").forEach((icon) => icon.textContent = "🔽");

                if (!isOpen) {
                    answer.style.display = "block";
                    toggle.textContent = "🔼";
                }
            });
        });
    });
</script>

</body>
</html>

<?php include '../footer.php'; ?>
