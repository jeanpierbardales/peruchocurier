<?php

?>

<?php
    $titulo = "Envíos USA - Perú";
    $correo = "perucho.courier@gmail.com";
    $telefono = "967-929-967";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?></title>
    <link rel="stylesheet" href="../estilos/estilos.css">
    <style>
    .info {
        text-align: center;
        font-family: 'Arial', sans-serif;
        font-size: 18px;
        margin-top: 20px;
    }

    .info h2 {
        font-weight: bold;
    }

    .ubicacion {
    text-align: center;
    font-family: 'Arial', sans-serif;
    font-size: 18px;
    margin-top: 20px;
}

.ubicacion h2 {
    font-weight: bold;
    margin-bottom: 10px;
}

</style>

</head>
<body>
    <?php include '../header.php'; ?>

    <!-- Carrusel de imágenes -->
    <div class="carousel">
    <div class="carousel-container">
        <img src="../img/paso1.jpg" class="elementor-size-large" alt="Imagen 1">
        <img src="../img/avion.jpg" class="elementor-size-large" alt="Imagen 2">
        <img src="../img/barco.jpg" class="elementor-size-large" alt="Imagen 3">
        <img src="../img/peruchos.jpg" class="elementor-size-large" alt="Imagen 4">
        <img src="../img/shein.jpg" class="elementor-size-large" alt="Imagen 5">
    </div>
    <button class="carousel-button prev">&#10094;</button>
    <button class="carousel-button next">&#10095;</button>
    
</div>

<script src="../public/js/carrusel.js"></script>
    
   <!-- Cuadro de información -->
<!-- Contenedor del anuncio -->
<div id="anuncio-modal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="cerrarAnuncio()">✖</span>
        <h2 class="headline">¿QUIERES GENERAR MÁS INGRESOS? 💰💰💰</h2>
        <p>
            EMPIEZA A EMPRENDER EN EL MUNDO 🌍 <br> 
            DE LAS IMPORTACIONES <br>
            EN NUESTRO ALMACÉN DE EE.UU CON DESTINO A PERÚ DE MANERA RÁPIDA Y SEGURA
            CONTAMOS CON 2 VUELOS ✈️ SEMANALES
        </p>
        <a href="registro.php" class="btn">Regístrate ahora</a>
    </div>
</div>

<!-- Estilos -->
<style>
    
    /* Nueva frase destacada */
    .headline {
        font-size: 34px;
        color: #ff7f00;
        font-weight: bold;
        text-transform: uppercase;
        margin-bottom: 15px;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
    }
    /* Fondo del modal (pantalla completa con fondo celeste) */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(135, 206, 235, 0.8); /* Celeste translúcido */
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    }
    /* Texto del modal */
    .modal-text {
        line-height: 1.6;
        font-weight: bold;
        text-align: center;
        max-width: 90%;
    }

    /* Cuadro de contenido (mitad de la pantalla, centrado) */
    .modal-content {
        width: 50%;
        height: 50%;
        background: blue;
        color:rgb(255, 255, 255); 
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        font-weight: bold;
        border-radius: 10px;
        box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        padding: 30px;
        line-height: 1.6;
        position: relative;
        border: 5px solid rgb(204, 7, 7); /* Borde azul oscuro */
    }

    /* Botón de cierre */
    .close-btn {
        position: absolute;
        top: 15px;
        right: 20px;
        font-size: 30px;
        cursor: pointer;
        color: #d9534f;
        font-weight: bold;
    }

    /* Botón de registro */
    .btn {
        background-color: #ff7f00;
        color: white;
        padding: 22px 50px; /* Aumentamos el tamaño del botón */
        border-radius: 8px;
        text-decoration: none;
        font-weight: bold;
        display: inline-block;
        margin-top: 20px;
        font-size: 28px; /* Aumentamos el tamaño del texto */
        border: 3px solid white; /* Borde blanco */
        transition: 0.3s;
    }

    .btn:hover {
        background-color: #e06b00;
        border-color: #ff7f00;
    }
</style>

<!-- Script para mostrar y cerrar el anuncio -->
<script>
    // Mostrar el anuncio al cargar la página
    window.onload = function() {
        document.getElementById('anuncio-modal').style.display = 'flex';
    };
    // Función para cerrar el anuncio
    function cerrarAnuncio() {
        document.getElementById('anuncio-modal').style.display = 'none';
    }
</script>
    <!-- Pasos para comprar -->
     <!-- Nueva sección "Comprar Paso a Paso" -->
     <div class="comprar-container">
    <img src="../img/tyron.jpg" class="img-lado" alt="Imagen Izquierda">
    
    <div class="comprar-texto">
        <h1 class="comprar-titulo">COMPRAR</h1>
        <div class="comprar-subtitulo">
        </div>
        <h2 class="comprar-paso">PASO A PASO</h2>
    </div>

    <img src="../img/tyron2.jpg" class="img-lado" alt="Imagen Derecha">
</div>
</div>

        <!-- CSS para el diseño -->
<style>
   .comprar-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 20px; /* Espacio entre los elementos */
    padding: 40px 20px;
    text-align: center;
}

.img-lado {
    width: 550px;  /* Ajusta el tamaño según necesites */
    height: auto;
}

.comprar-texto {
    text-align: center;
}

.comprar-titulo {
    font-size: 5rem;
    font-weight: bold;
    color: #FFD700; /* Amarillo dorado */
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.8);
}

.comprar-subtitulo {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: -20px 0 10px;
}

.comprar-subtitulo .linea {
    width: 50px;
    height: 2px;
    background-color: #3498db;
    margin: 0 10px;
}

.comprar-subtitulo .texto {
    font-size: 1.2rem;
    font-weight: bold;
    color: #964B00; /* Marrón oscuro */
}

.comprar-paso {
    font-size: 2rem;
    font-weight: bold;
    color: #E67E22; /* Naranja */
    text-shadow: 0 0 5px rgba(230, 126, 34, 0.8);
}
.paso img {
    width: 100px; /* Ajusta este valor según el tamaño deseado */
    height: auto; /* Mantiene la proporción */
}

</style>
    <section class="pasos" id="como-comprar">
        <div class="paso">
            <div class="paso-texto">
                <img src="../img/tienda.png" alt="Icono Paso 1" class="paso-icono"> 
                <h3>Paso 1: Elegir la tienda</h3>
                <p>Elige la tienda donde deseas comprar. Te ofrecemos una lista de opciones seguras.</p>
            </div>
            <img src="../img/paso1.jpg" alt="Paso 1">
        </div>
        <div class="paso">
            <div class="paso-texto">
            <img src="../img/mapa.png" alt="Icono Paso 2" class="paso-icono"> 
                <h3>Paso 2: Usar nuestra dirección</h3>
                <p>Usa nuestra dirección en USA como destino de tu compra.</p>
            </div>
            <img src="../img/paso2.jpg" alt="Paso 2">
        </div>
        <div class="paso">
            <div class="paso-texto">
                <img src="../img/form.png" alt="Icono Paso 3" class="paso-icono"> 
                <h3>Paso 3: Registra tu compra</h3>
                <p>Ingresa los detalles de tu compra en nuestra plataforma.</p>
            </div>
            <img src="../img/paso3.jpg" alt="Paso 3">
        </div>
        <div class="paso">
            <div class="paso-texto">
                <img src="../img/receptor.png" alt="Icono Paso 4" class="paso-icono"> 
                <h3>Paso 4: Recibe en Perú</h3>
                <p>Te notificaremos cuando tu compra llegue a Perú.</p>
            </div>
            <img src="../img/paso4.jpg" alt="Paso 4">
        </div>
    </section>
    
    <!-- Sección de Reseña de Clientes -->
    <div class="reseña-clientes">
    <h2>RESEÑA DE CLIENTES</h2>
    <div class="videos-container">
        <div class="video-box">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/zlgaD9zLZI8" frameborder="0" allowfullscreen></iframe>
        </div>
        <div class="video-box">
            <video width="560" height="315" controls>
                <source src="../img/a.mp4" type="video/mp4">
                Tu navegador no soporta la reproducción de video.
            </video>
        </div>
        <style>
            .reseña-clientes {
    text-align: center;
    margin: 50px 0;
    padding: 20px;
    background-color: #f8f9fa;
    border-radius: 10px;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.reseña-clientes h2 {
    font-size: 28px;
    color: #002f6c;
    margin-bottom: 20px;
    font-weight: bold;
}

/* Contenedor de los videos */
.videos-container {
    display: flex;
    justify-content: center;  /* Centra los videos horizontalmente */
    align-items: center;  /* Alinea verticalmente */
    gap: 20px; /* Espacio entre videos */
    flex-wrap: wrap; /* Se adaptará en pantallas pequeñas */
}

/* Estilos para cada video */
.video-box {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 560px; /* Tamaño fijo para mantener proporción */
    height: 315px;
}

.video-box iframe,
.video-box video {
    width: 100%;
    height: 100%;
}

        </style>
    </div>
</div>


    <!-- Sección de Tiendas al inicio -->
    <div class="mejores-tiendas">
    <h2 class="titulo-tiendas">Compra en las mejores tiendas de USA</h2>
    <div class="contenedor-tiendas">
        <!-- Amazon -->
        <a href="https://www.amazon.com" target="_blank" class="tienda">
            <img src="../img/amazon.png" alt="Amazon">
        </a>
        <!-- eBay -->
        <a href="https://www.ebay.com" target="_blank" class="tienda">
            <img src="../img/ebay.png" alt="eBay">
        </a>
        <!-- Walmart -->
        <a href="https://www.walmart.com" target="_blank" class="tienda">
            <img src="../img/walmart.png" alt="Walmart">
        </a>
        <!-- Target -->
        <a href="https://www.target.com" target="_blank" class="tienda">
            <img src="../img/target.jpg" alt="Target">
        </a>
        <a href="https://www.adidas.com/us" target="_blank" class="tienda">
            <img src="../img/adidas.jpg" alt="Adidas">
        </a>
        <a href="https://www.nike.com/mx/?_android_redirect=https://www.nike.com/&_fallback_redirect=https://www.nike.com/&_ios_redirect=https://www.nike.com/&cid=4942550&cjevent=b9e4ec88047a11f082f800650a1cb829&cl=b9e4ec88047a11f082f800650a1cb829&cp=usns_aff_nike__PID_46157_Ebates%20Performance%20Marketing,%20Inc.%20dba%20Rakuten%20Rewards&pcn=cj_mobile_inactivity-0d&pcrid=13672572&pcrn=Nike%20Homepage&psid=46157&psn=Ebates%20Performance%20Marketing,%20Inc.%20dba%20Rakuten%20Rewards&referrer=singular_click_id%3D38ee60f1-6a69-490f-9e2e-f0442561a38c&sl_id=jjo0&gad_source=1&gclid=Cj0KCQjws-S-BhD2ARIsALssG0au9mHyIk0kPD7SLOtsbQgOnVlbdT7DjtS5EA49z6qowLgMo6eG8qcaAtQwEALw_wcB" target="_blank" class="tienda">
            <img src="../img/nike.png" alt="Nike">
        </a>
        <a href="https://thefisherprice.com/" target="_blank" class="tienda">
            <img src="../img/fisher.png" alt="Fisher-Price">
        </a>
        <a href="https://www.apple.com/" target="_blank" class="tienda">
            <img src="../img/aple.png" alt="Aple USA">
        </a>
        <a href="https://www.bestbuy.com/?intl=nosplash" target="_blank" class="tienda">
            <img src="../img/bets.png" alt="BEST BUY">
        </a>
        <a href="https://www.toysrus.com/?srsltid=AfmBOoovfgYnH6jLNMdbj0Frb6Uzk7H0nG82_waPMg8w4xUFXDeHVaWt" target="_blank" class="tienda">
            <img src="../img/toyrus.png" alt="Toyrus">
        </a>
        <a href="https://www.victoriassecret.com/us/" target="_blank" class="tienda">
            <img src="../img/victoria.png" alt="Vcitoria Secret">
        </a>
        <a href="https://www.gap.com/" target="_blank" class="tienda">
            <img src="../img/gap.png" alt="Gap">
        </a>
        <a href="https://www.carters.com/" target="_blank" class="tienda">
            <img src="../img/carter.png" alt="Carte´s">
        </a>
        <a href="https://www.bose.pe/es_pe/index.html" target="_blank" class="tienda">
            <img src="../img/bose.png" alt="Bose">
        </a>
        <a href="https://www.macys.com/" target="_blank" class="tienda">
            <img src="../img/macys.png" alt="Macys">
        </a>
        <a href="https://www.shoecarnival.com/" target="_blank" class="tienda">
            <img src="../img/shoe.png" alt="Shoe">
        </a>
        <a href="https://pe.shein.com/?_t=1742366778561&adid=726974895727&cid=21745015161&gad_source=1&gclid=Cj0KCQjws-S-BhD2ARIsALssG0aPY455djfAWsi3tPTZKBJ11l25YY3Qb28vPLBMKV09wuPcGm717kEaAveZEALw_wcB&kwd=kwd-344122486966&network=g&onelink=6%2F4afn6lcntjq2&pf=GOOGLE&requestId=olw-4irdhet4krgw&setid=163252167290&url_from=pegooglebrandshein_srsa_normal5_onelink01_20241227" target="_blank" class="tienda">
            <img src="../img/shein.png" alt="Shein">
        </a>
        <a href="https://theordinary.com/en-us" target="_blank" class="tienda">
            <img src="../img/ordi.png" alt="Ordinary">
        </a>
        <a href="https://www.ea.com/sports" target="_blank" class="tienda">
            <img src="../img/ea.png" alt="Ea-Sports">
        </a>
        <a href="https://www.zappos.com/" target="_blank" class="tienda">
            <img src="../img/zappos.png" alt="Zappos">
        </a>
        <a href="https://www.michaelkors.com/" target="_blank" class="tienda">
            <img src="../img/mi.png" alt="Michaelkors">
        </a>
        <a href="https://www.nautica.eu.com/?srsltid=AfmBOopWEq0Llc0ugpV4fvbRhyBGPCe7_hXuWZ_7opYMT_lO44XGhClg" target="_blank" class="tienda">
            <img src="../img/nau.jpg" alt="Nautica">
        </a>
        <a href="https://www.ralphlauren.com/" target="_blank" class="tienda">
            <img src="../img/ralph.jpg" alt="Palphlauren">
        </a>
        <a href="https://www.aeropostale.com/" target="_blank" class="tienda">
            <img src="../img/aero.png" alt="aerospostale">
        </a>
        <a href="https://www.armani.com/es-us/" target="_blank" class="tienda">
            <img src="../img/armani.png" alt="armani">
        </a>
        <a href="hhttps://www.6pm.com/" target="_blank" class="tienda">
            <img src="../img/6pm.jpg" alt="O6pm">
        </a>
        <a href="https://pe.tommy.com/" target="_blank" class="tienda">
            <img src="../img/tom.png" alt="tommy">
        </a>
        <a href="https://www.dickssportinggoods.com/" target="_blank" class="tienda">
            <img src="../img/dick.jpg" alt="dicks">
        </a>
        <a href="https://global.lacoste.com/es/homepage" target="_blank" class="tienda">
            <img src="../img/lacoste.png" alt="Lacoste">
        </a>

    </div>
</div>

    <!-- Dirección de la tienda en Perú -->
    <section class="ubicacion">
    <h2>Nuestra Tienda en Perú</h2>
    <iframe 
        width="100%" 
        height="300" 
        style="border:0;" 
        loading="lazy" 
        allowfullscreen 
        referrerpolicy="no-referrer-when-downgrade"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d487.754115028082!2d-77.06640072788565!3d-12.04125462461518!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105cfc6c7c3a9c3%3A0xd9322e3ce30ab172!2sPERUCHO%20COURIER!5e0!3m2!1ses-419!2spe!4v1742368546524!5m2!1ses-419!2spe" >
    </iframe>
</section>

    
    <?php include '../footer.php'; ?>
</body>
</html>
