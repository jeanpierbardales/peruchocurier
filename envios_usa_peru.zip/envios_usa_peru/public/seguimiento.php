<?php include '../header.php'; ?>

<section class="seguimiento">
    <h2>DALE UN SEGUIMIENTO A TUS PEDIDOS</h2>
    <div class="seguimiento-contenedor">
        <a href="https://www.ups.com/track" class="seguimiento-item" target="_blank">
            <img src="../img/icono_ups.png" alt="UPS">
            <span>Seguimiento UPS</span>
        </a>
        <a href="https://www.fedex.com/en-us/tracking.html" class="seguimiento-item" target="_blank">
            <img src="../img/icono-fedex.jpg" alt="FedEx">
            <span>Seguimiento FedEx</span>
        </a>
        <a href="https://www.17track.net/es" class="seguimiento-item" target="_blank">
            <img src="../img/icono-17track.png" alt="USPS">
            <span>Seguimiento 17track</span>
        </a>
        <a href="https://www.dhl.com/global-en/home/tracking.html" class="seguimiento-item" target="_blank">
            <img src="../img/icono-dhl.png" alt="DHL">
            <span>Seguimiento DHL</span>
        </a>
        <a href="https://tools.usps.com/go/TrackConfirmAction_input" class="seguimiento-item" target="_blank">
            <img src="../img/usps.png" alt="USPS">
            <span>Seguimiento USPS</span>
        </a>
        <a href="https://parcelsapp.com/en/carriers/china-post" class="seguimiento-item" target="_blank">
            <img src="../img/china.jpg" alt="USPS">
            <span>China Post</span>
        </a>
    </div>
</section>

<?php include '../footer.php'; ?>

<style>
/* 🌟 Estilos Mejorados */
<style>
/* 🌟 Contenedor General */
.seguimiento {
    text-align: center;
    background: linear-gradient(to right, #ff0000, #0000ff);
    padding: 60px 20px;
    color:  #ff0000;
    border-radius: 10px;
    margin: 30px auto;
    max-width: 1200px;
}

/* 🌟 Título más grande con sombra */
.seguimiento h2 {
    text-align: center;
    font-size: 32px;
    font-weight: bold;
    text-shadow: 2px 2px 5px rgba(255, 230, 0, 0.9);
    color:  #ff0000;
    margin-bottom: 30px;
    opacity: 0;
    transform: translateY(-20px);
    animation: fadeInUp 0.8s ease-out forwards;
}

/* 🌟 Contenedor con flexbox */
.seguimiento-contenedor {
    display: flex;
    justify-content: center;
    gap: 25px;
    flex-wrap: wrap;
}

/* 🌟 Estilos de cada cuadro de seguimiento */
.seguimiento-item {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
    text-align: center;
    width: 220px;
    height: 220px;
    transition: transform 0.3s ease-in-out;
    text-decoration: none;
    color: black;
    font-weight: bold;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: translateY(20px);
}

/* 🌟 Tamaño más grande de los iconos */
.seguimiento-item img {
    width: 90px;
    height: 90px;
    margin-bottom: 15px;
}

/* 🌟 Texto debajo del icono */
.seguimiento-item span {
    font-size: 18px;
    font-weight: bold;
}

/* 🌟 Animación de entrada */
@keyframes fadeInUp {
    0% {
        opacity: 0;
        transform: translateY(20px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

/* 🌟 Efecto hover */
.seguimiento-item:hover {
    transform: scale(1.1);
}

/* 🌟 Mostrar elementos con animación en orden */
.seguimiento-item:nth-child(1) { animation: fadeInUp 0.8s ease-out 0.3s forwards; }
.seguimiento-item:nth-child(2) { animation: fadeInUp 0.8s ease-out 0.6s forwards; }
.seguimiento-item:nth-child(3) { animation: fadeInUp 0.8s ease-out 0.9s forwards; }
.seguimiento-item:nth-child(4) { animation: fadeInUp 0.8s ease-out 1.2s forwards; }
.seguimiento-item:nth-child(5) { animation: fadeInUp 0.8s ease-out 1.5s forwards; }
.seguimiento-item:nth-child(6) { animation: fadeInUp 0.8s ease-out 1.8s forwards; }
</style>

</style>
