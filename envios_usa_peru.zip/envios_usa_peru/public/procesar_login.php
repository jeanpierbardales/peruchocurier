<?php
session_start();  // Iniciar sesión
include '../config/conexion.php';  // Conectar a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password)) {
        // Buscar usuario en la base de datos
        $query = "SELECT id, nombre, apellidos, password FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $nombre, $apellidos, $hashed_password);
            $stmt->fetch();

            // Verificar contraseña
            if (password_verify($password, $hashed_password)) {
                // Guardar datos en sesión
                $_SESSION['usuario_id'] = $id;
                $_SESSION['usuario_nombre'] = $nombre;
                $_SESSION['usuario_apellidos'] = $apellidos;
                $_SESSION['usuario_email'] = $email;

                // Redirigir al dashboard
                header("Location: ../dashboard.php");
                exit();
            } else {
                $_SESSION['error'] = "Contraseña incorrecta.";
            }
        } else {
            $_SESSION['error'] = "Usuario no encontrado.";
        }
        $stmt->close();
    } else {
        $_SESSION['error'] = "Por favor, completa todos los campos.";
    }
    $conn->close();
}

// Volver al login si hay un error
header("Location: ../login.php");
exit();
?>
