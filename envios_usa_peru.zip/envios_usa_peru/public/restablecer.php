<?php
include '../config/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = trim($_POST['token'] ?? '');
    $nueva_contrasena = trim($_POST['nueva_contrasena'] ?? ''); // Cambiado a 'nueva_contrasena'

    if (empty($token) || empty($nueva_contrasena)) {
        die("❌ Token inválido o contraseña vacía.");
    }

    // Verificar si el token es válido y no ha expirado
    $sql = "SELECT usuario_id FROM recuperacion WHERE token = ? AND expira > NOW() LIMIT 1";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {  
        die("❌ Error en la consulta SQL: " . $conn->error);  // 📌 Detecta el error en prepare()
    }

    $stmt->bind_param("s", $token);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();
        $usuario_id = $usuario['usuario_id'];

        // Encriptar la nueva contraseña
        $hashed_password = password_hash($nueva_contrasena, PASSWORD_DEFAULT);

        // Actualizar la contraseña en la base de datos
        $update_sql = "UPDATE usuarios SET password = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);

        if (!$update_stmt) {  
            die("❌ Error en la actualización SQL: " . $conn->error);  // 📌 Detecta el error en prepare()
        }

        $update_stmt->bind_param("si", $hashed_password, $usuario_id);

        if ($update_stmt->execute()) {
            // Eliminar el token usado
            $delete_sql = "DELETE FROM recuperacion WHERE usuario_id = ?";
            $delete_stmt = $conn->prepare($delete_sql);

            if (!$delete_stmt) {  
                die("❌ Error al eliminar token: " . $conn->error);  // 📌 Detecta el error en prepare()
            }

            $delete_stmt->bind_param("i", $usuario_id);
            $delete_stmt->execute();
            $delete_stmt->close();

            echo "<script>alert('✅ Contraseña actualizada con éxito.'); window.location.href='login.php';</script>";
        } else {
            echo "❌ Error al actualizar la contraseña.";
        }

        $update_stmt->close();
    } else {
        echo "❌ Token inválido o expirado.";
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #1f1f91, #ff7f00);
            color: white;
            text-align: center;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
            color: black;
            width: 350px;
        }

        h2 {
            margin-bottom: 20px;
            color: #1f1f91;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #ff7f00;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        button:hover {
            background-color: #e66c00;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Restablecer Contraseña</h2>
        <form method="POST">
            <input type="hidden" name="token" value="<?= htmlspecialchars($_GET['token'] ?? '') ?>">
            
            <label for="nueva_contrasena">Nueva Contraseña:</label>
            <input type="password" name="nueva_contrasena" required>

            <button type="submit">Actualizar Contraseña</button>
        </form>
    </div>
</body>
</html>
