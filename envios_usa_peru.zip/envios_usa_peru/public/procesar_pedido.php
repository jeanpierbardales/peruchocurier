<?php
// Iniciar sesión si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Incluir conexión a la base de datos
include __DIR__ . '/../config/conexion.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    die("Error: Usuario no autenticado.");
}

// Obtener datos del formulario con validación
$usuario_id = $_SESSION['usuario_id'];
$web_compra = $_POST['web_compra'] ?? '';
$productos = $_POST['productos'] ?? '';
$precio = $_POST['precio'] ?? '';
$seguimiento = $_POST['seguimiento'] ?? '';
$codigo_pago = strtoupper(substr(md5(time() . rand()), 0, 8)); // Genera un código único
$estado = "pendiente"; // Nuevo estado del pedido

// Manejo de subida de factura
$directorio_destino = __DIR__ . "/facturas/";
if (!file_exists($directorio_destino)) {
    mkdir($directorio_destino, 0775, true);
}

$ruta_archivo = null;
if ($_FILES['factura']['error'] === UPLOAD_ERR_OK) {
    $nombre_archivo = basename($_FILES['factura']['name']);
    $ruta_archivo = "facturas/" . $nombre_archivo;
    move_uploaded_file($_FILES['factura']['tmp_name'], __DIR__ . "/" . $ruta_archivo);
}

// Insertar pedido en la base de datos
$sql = "INSERT INTO pedidos (usuario_id, web_compra, productos, precio, seguimiento, codigo_pago, estado, factura) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error en la consulta: " . $conn->error);
}

$stmt->bind_param("isssssss", $usuario_id, $web_compra, $productos, $precio, $seguimiento, $codigo_pago, $estado, $ruta_archivo);

if ($stmt->execute()) {
    echo "<script>alert('✅ Tu pedido fue registrado. Para continuar, realiza el pago y envía el código al WhatsApp de la empresa.\\n📌 Números de pago: \\n✅ Yape: 997214526 \\n✅ Plin: 997214526 \\n📌 Código de Pago: $codigo_pago');</script>";
    echo "<script>window.location.href='dashboard.php?page=mis_ordenes';</script>";
} else {
    echo "<p>Error al registrar el pedido.</p>";
}

$stmt->close();
$conn->close();
?>

