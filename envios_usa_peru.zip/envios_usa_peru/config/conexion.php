<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "perucho_currier";

// Crear conexión
$conn = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

?>
