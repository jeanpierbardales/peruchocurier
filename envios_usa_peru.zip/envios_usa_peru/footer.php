<footer>
    <div class="footer-container">
        <!-- Métodos de Pago -->
        <div class="footer-section">
            <h3>Métodos de Pago</h3>
            <div class="divider"></div>
            <div class="logos-pago">
                <img src="../img/yape.jpg" alt="Visa">
                <img src="../img/plin.png" alt="MasterCard">
                <img src="../img/bcp.png" alt="PayPal">
                <img src="../img/inter.png" alt="Transferencia Bancaria">
            </div>
            <p>NUMERO DE CUENTA:<br>
                    RAZON SOCIAL: PERUCHO COURIER & MOAD STORE EIRL<br>
                    📌CUENTA BBVA: 0011-0141-0100069250
                    CCI:011-141-000100069250-97
            </p>
            <p>YAPE/PLIN: 997-214-526
            Edwin Sanchez</p>
        </div>
        <!-- Horarios y Redes Sociales -->
        <div class="footer-section">
            <h3>Contáctanos</h3>
            <div class="divider"></div>
            <p>🕒 Lunes - Viernes: 9:00 AM - 6:00 PM</p>
            <p>🕒 Sábados: 9:00 AM - 12:00 PM</p>

            <h3>Síguenos</h3>
            <div class="redes">
                <a href="#"><img src="../img/fb.png" alt="Facebook"></a>
                <a href="#"><img src="../img/instagram.png" alt="Instagram"></a>
                <a href="#"><img src="../img/t.png" alt="TikTok"></a>
            </div>
        </div>

        <!-- Políticas -->
        <div class="footer-section">
            <h3>Información Legal</h3>
            <div class="divider"></div>
            <a href="legal.php">Términos y Condiciones</a><br>
            <a href="legal.php">Política de Privacidad</a>
        </div>
    </div>
    <style>
        /* Footer */
footer {
    background:rgb(53, 39, 184); /* Azul oscuro */
    color: white;
    padding: 30px 0;
    text-align: center;
    font-weight: bold;
}

.footer-container {
    display: flex;
    justify-content: space-between; /* Separa las secciones */
    max-width: 1600px; /* Aumenta el ancho máximo */
    margin: auto;
    flex-wrap: wrap; /* Permite ajuste en pantallas pequeñas */
    text-align: left;
    gap: 85px; /* Agrega más espacio entre secciones */
}

.footer-section {
    flex: 1;
    min-width: 200px; /* Asegura un tamaño mínimo */
    padding: 20px; /* Aumenta la separación interna */
}

.footer-section h3 {
    font-size: 50px;
    margin-bottom: 6px;
    font-weight: bold;
}

.divider {
    width: 40px;
    height: 3px;
    background-color: #ffcc00; /* Línea amarilla */
    margin-bottom: 15px;
}

.logos-pago img,
.redes img {
    width: 60px;
    height: auto;
    margin: 5px;
}
.footer-section p{
    font-size: 20px;
    color: #ffcc00;
}
.footer-section a {
    color: #ffcc00;
    text-decoration: none;
    display: block;
    margin-top: 8px;
    font-size: 20px;
    margin-bottom: 6px;
    font-weight: bold;
}

.footer-section a:hover {
    text-decoration: underline;
}
/* .rede*/

.redes{
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px; /* Espaciado entre íconos */
    padding: 10px;
    border-radius: 8px;
}

.redes img {
    width: 60px; /* Ajusta el tamaño de los íconos */
    height: 60px;
    transition: transform 0.3s ease-in-out;
}

.redes img:hover {
    transform: scale(1.2); /* Efecto de agrandamiento */
}


    </style>
</footer>

