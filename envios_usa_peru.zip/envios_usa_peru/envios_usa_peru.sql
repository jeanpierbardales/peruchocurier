CREATE DATABASE perucho_currier CHARACTER SET utf8mb4 COLLATE UTF8MB4_UNICODE_CI;
USE perucho_currier;

-- Tabla de Clientes
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    movil VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    dni_numero VARCHAR(8) NOT NULL,
    dni_direccion VARCHAR(255) NOT NULL,
    dni_provincia VARCHAR(100) NOT NULL,
    dni_pdf VARCHAR(255) NULL,
    ruc_numero VARCHAR(20) NULL,
    ruc_razon_social VARCHAR(255) NULL,
    ruc_direccion VARCHAR(255) NULL,
    ruc_provincia VARCHAR(100) NULL,
    ruc_pdf VARCHAR(255) NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Tabla de Pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    web_compra VARCHAR(255) NOT NULL,
    productos TEXT NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    seguimiento VARCHAR(255) NOT NULL,
    fecha_llegada DATE NOT NULL,
    factura VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

ALTER TABLE pedidos ADD COLUMN codigo_pago VARCHAR(8) NOT NULL AFTER seguimiento;
ALTER TABLE pedidos ADD COLUMN estado VARCHAR(20) NOT NULL DEFAULT 'pendiente' AFTER codigo_pago;


CREATE TABLE direcciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    nombre VARCHAR(100),
    apellidos VARCHAR(100),
    empresa VARCHAR(100) NULL,
    pais VARCHAR(50),
    direccion VARCHAR(255),
    apartamento VARCHAR(100) NULL,
    ciudad VARCHAR(100),
    provincia VARCHAR(100),
    codigo_postal VARCHAR(20),
    telefono VARCHAR(20),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

ALTER TABLE usuarios ADD COLUMN foto_perfil VARCHAR(255) NULL;

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE recuperacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expira DATETIME NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX (token) 
);




SELECT * FROM recuperacion;
SELECT * FROM recuperacion WHERE token = 'AQUI_EL_TOKEN_QUE_RECIBES';


SELECT * FROM usuarios;

SELECT * FROM pedidos;
INSERT INTO usuarios (email, nombre, apellidos, movil, password, dni_numero, dni_direccion, dni_provincia, dni_pdf, ruc_numero, ruc_razon_social, ruc_direccion, ruc_provincia, ruc_pdf) 
VALUES ('prueba@email.com', 'Prueba', 'Usuario', '123456789', '123456', '12345678', 'Direccion', 'Provincia', 'dni.pdf', NULL, NULL, NULL, NULL, NULL);
